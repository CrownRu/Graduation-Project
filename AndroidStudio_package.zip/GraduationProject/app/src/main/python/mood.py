from ckip_transformers import __version__
from ckip_transformers.nlp import CkipWordSegmenter, CkipPosTagger, CkipNerChunker
from snownlp import SnowNLP

# Show version
print(__version__)

# Initialize drivers
print("Initializing drivers ... WS")
ws_driver = CkipWordSegmenter(model="bert-base", device=-1)
print("Initializing drivers ... POS")
pos_driver = CkipPosTagger(model="bert-base", device=-1)
print("Initializing drivers ... NER")
ner_driver = CkipNerChunker(model="bert-base", device=-1)
print("Initializing drivers ... all done")
print()
def clean(sentence_ws, sentence_pos):
  short_with_pos = []
  short_sentence = []
  stop_pos = set(['VHC', 'VJ', 'VK', 'Dfa', 'Dk', 'VA', 'VAC', 'VB']) # 詞性不保留
  for word_ws, word_pos in zip(sentence_ws, sentence_pos):
    # 只留動詞、形容詞和副詞
    is_N_or_V = word_pos.startswith("V") or word_pos.startswith("A") or word_pos.startswith("D")
    # 去掉某些詞性
    is_not_stop_pos = word_pos not in stop_pos
    # 只剩一個字的詞也不留
    is_not_one_charactor = not (len(word_ws) == 1)
    # 組成串列
    if is_N_or_V and is_not_stop_pos and is_not_one_charactor:
      short_with_pos.append(f"{word_ws}({word_pos})")
      short_sentence.append(f"{word_ws}")
  return (" ".join(short_sentence), " ".join(short_with_pos))

def get():
    text = [
        '昨晚的晚餐太美味了，我真的很滿足。'
    ]
    ws = ws_driver(text)
    pos = pos_driver(ws)
    ner = ner_driver(text)
    print()
    print('=====')
    for sentence, sentence_ws, sentence_pos, sentence_ner in zip(text, ws, pos, ner):
        print("原文：")
        print(sentence)
        (short, res) = clean(sentence_ws, sentence_pos)
        print("斷詞後：")
        print(short)
        print("斷詞後+詞性標注：")
        print(res)
        print('=====')

    total_score = 0
    str_short = short.split(' ')
    print(str_short)
    for word in str_short:
        s1=SnowNLP(word)
        print(word,end=' ')
        print(s1.sentiments)
        total_score+=s1.sentiments
    score=total_score/len(str_short)
    #print(len(clean_word))
    print("\n平均分數 : ")
    print(score)
    return score