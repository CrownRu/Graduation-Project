import psycopg2
from psycopg2 import Error
import datetime
import re
from collections import defaultdict
import matplotlib.pyplot as plt
from datetime import datetime
from datetime import timedelta

def draw_combined_map_plot(map1, map2, map3, map4, specific_date, n):
    combined_map = defaultdict(list)

    for date, values in map1.items():
        combined_map[date].extend(values)

    for date, values in map2.items():
        combined_map[date].extend(values)

    for date, values in map3.items():
        combined_map[date].extend(values)
    
    for date, values in map4.items():
        combined_map[date].extend(values)
    print(combined_map)
    
    plt.figure(figsize=(10, 6))

    if n == 1:
        if specific_date in combined_map:
            times, scores = zip(*combined_map[specific_date])
            plt.plot(times, scores, marker='o', linestyle='-', linewidth=7)
            plt.xlabel('Time')
            plt.ylabel('Score')
            plt.title(f'Flows on {specific_date}')
            plt.xticks(rotation=45)
            plt.tight_layout()
        else:
            print(f"No data available for {specific_date}")

    elif n > 1:
        start_date = datetime.strptime(specific_date, "%Y-%m-%d") - timedelta(days=n - 1)
        end_date = datetime.strptime(specific_date, "%Y-%m-%d")
        daily_average_scores = defaultdict(list)

        for date, values in combined_map.items():
            current_date = datetime.strptime(date, "%Y-%m-%d")
            if start_date <= current_date <= end_date:
                for _, score in values:
                    date_key = current_date.strftime('%Y-%m-%d')
                    daily_average_scores[date_key].append(score)

        if daily_average_scores:
            average_scores = [sum(scores) / len(scores) for scores in daily_average_scores.values()]
            dates = list(daily_average_scores.keys())

            plt.plot(dates, average_scores, linestyle='-', linewidth=7)
            plt.xlabel('Date')
            plt.ylabel('Average Score')
            plt.title(f'Average Flows from {dates[0]} to {dates[-1]}')
            plt.xticks(rotation=45)
            plt.tight_layout()
        else:
            print(f"No data available for the past {n} days from {specific_date}")

    plot_object = plt.gcf()
    plt.close() 

    return plot_object

#Diary
diary_map = {}
try:
    connection = psycopg2.connect(
        host="140.127.220.89",
        port="5432",
        database="postgres",
        user="postgres",
        password="CrownRu"
    )

    cursor= connection.cursor()
    diary_query = "SELECT * FROM diary d order by d.diary_date, d.diary_time"

    cursor.execute(diary_query)
    diary_rows = cursor.fetchall()

    for row in range(len(diary_rows)):
        date = str(diary_rows[row][3])
        time = str(diary_rows[row][4])
        score = float(diary_rows[row][2])
        if score == -1.0:
            continue
        else:
            if date in diary_map:
                diary_map[date].append((time,score))
            else:
                diary_map[date] = [(time, score)]
    print(diary_map)

except Error as e:
    print(f"Error while connecting to PostgreSQL: {e}")

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")

#Facebook
fb_map = {}
try:
    connection = psycopg2.connect(
        host="140.127.220.89",
        port="5432",
        database="postgres",
        user="postgres",
        password="CrownRu"
    )

    cursor= connection.cursor()
    facebook_query = "SELECT * FROM facebook f order by f.fb_post_date, f.fb_post_time"

    cursor.execute(facebook_query)
    facebook_rows = cursor.fetchall()

    
    for row in range(len(facebook_rows)):
        date = str(facebook_rows[row][3])
        time = str(facebook_rows[row][4])
        score = float(facebook_rows[row][2])
        if score == -1.0:
            continue
        else:
            if date in fb_map:
                fb_map[date].append((time,score))
            else:
                fb_map[date] = [(time, score)]
    print(fb_map)

except Error as e:
    print(f"Error while connecting to PostgreSQL: {e}")

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")

#instagram
ig_map = {}
try:
    connection = psycopg2.connect(
        host="140.127.220.89",
        port="5432",
        database="postgres",
        user="postgres",
        password="CrownRu"
    )

    cursor= connection.cursor()
    instagram_query = "SELECT * FROM instagram i order by i.ins_post_date, i.ins_post_time"

    cursor.execute(instagram_query)
    instagram_rows = cursor.fetchall()

    
    for row in range(len(instagram_rows)):
        date = str(instagram_rows[row][3])
        time = str(instagram_rows[row][4])
        score = float(instagram_rows[row][2])
        if score == -1.0:
            continue
        else:
            if date in ig_map:
                ig_map[date].append((time,score))
            else:
                ig_map[date] = [(time, score)]
    print(ig_map)

except Error as e:
    print(f"Error while connecting to PostgreSQL: {e}")

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")

#txt
txt_map = {}
try:
    connection = psycopg2.connect(
        host="140.127.220.89",
        port="5432",
        database="postgres",
        user="postgres",
        password="CrownRu"
    )

    cursor= connection.cursor()
    txt_query = "SELECT * FROM txt t order by t.txt_date, t.txt_time"

    cursor.execute(txt_query)
    txt_rows = cursor.fetchall()
    
    for row in range(len(txt_rows)):
        date = str(txt_rows[row][2])
        time = str(txt_rows[row][3])
        score = float(txt_rows[row][4])
        if score == -1.0:
            continue
        else:
            if date in txt_map:
                txt_map[date].append((time,score))
            else:
                txt_map[date] = [(time, score)]
    print(txt_map)

except Error as e:
    print(f"Error while connecting to PostgreSQL: {e}")

finally:
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")

rslt_plot = draw_combined_map_plot(fb_map, ig_map, diary_map, txt_map, '2023-01-01', 7)
rslt_plot.savefig('plot.png')