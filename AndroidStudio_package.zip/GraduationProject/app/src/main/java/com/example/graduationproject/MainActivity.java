package com.example.graduationproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity{
    static Context context;
    static MoodPics moodPics;
    CalendarView calendarView;
    Calendar calendar;
    static ImageView mood;
    View write;
    ImageView fb;
    ImageView line;
    ImageView mood_line;
    ImageView mood_fb;
    ImageView ig;
    ImageView mood_ig;
    ImageView house;
    ImageView report;
    View self;
    static TextView userName;
    TextView date;
    String from;
    static int user_number;
    static String user_name;
    static String line_id; //0
    static String fb_link; //1
    static String ins_link; //2
    String[] today;
    static double post_score = -1;
    static double txt_score = -1;
    static double fb_score = -1;
    static double ins_score = -1;
    static int txt_num;
    static int fb_num;
    static int ins_num;

    private static final int PICK_TXT_FILE_REQUEST = 1;

    static Drawable question;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCollector.addActivity(this);

        context = this;
        question = getResources().getDrawable(R.drawable.question);

        Intent i = getIntent();
        from = i.getStringExtra("from");
        user_number = i.getIntExtra("user_number",0);
        //System.out.println("user_number = "+user_number);

        try {
            getuser();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        moodPics = new MoodPics(this);

        line = findViewById(R.id.line);
        //System.out.println("line_id = "+line_id);
        line.setOnClickListener(view -> {
            if(line_id == null || line_id.equals("null") || line_id.isEmpty()){
                showDialog("Line");
            } else {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("text/plain"); // 限制文件类型为.txt文件
                startActivityForResult(intent, PICK_TXT_FILE_REQUEST);
            }
        });
        mood_line = findViewById(R.id.mood_line);
        mood_line.setOnClickListener(view -> {
            try {
                getLineMood();
                if(txt_num > 0){
                    mood_line.setImageDrawable(moodPics.getMoodPic(txt_score));
                }else Toast.makeText(this, "今日尚未上傳聊天紀錄", Toast.LENGTH_SHORT).show();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        fb = findViewById(R.id.fb);
        mood_fb = findViewById(R.id.mood_fb);
        fb.setOnClickListener(view -> {
            System.out.println("進入");
            if(fb_link == null || fb_link.equals("null")){
                showDialog("FB");
            }else{
                try {
                    System.out.println("抓fb心情");
                    getFBmood();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(fb_score < 0){
                    Toast.makeText(context, "無貼文可分析", Toast.LENGTH_SHORT).show();
                }else{
                    mood_fb.setImageDrawable(moodPics.getMoodPic(fb_score));
                    Toast.makeText(context, "已更新心情", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ig = findViewById(R.id.ig);
        mood_ig = findViewById(R.id.mood_ig);
        ig.setOnClickListener(view -> {
            if(ins_link == null || ins_link.equals("null")){
                showDialog("IG");
            }else{
                try {
                    getIGMood();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(ins_score < 0){
                    Toast.makeText(this, "無貼文可分析", Toast.LENGTH_SHORT).show();
                }else{
                    mood_ig.setImageDrawable(moodPics.getMoodPic(ins_score));
                    Toast.makeText(this, "已更新心情", Toast.LENGTH_SHORT).show();
                }
            }
        });

        house = findViewById(R.id.house);
        house.setOnClickListener(view -> {
            showHouseDialog();
        });

        report = findViewById(R.id.report);
        report.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(this , ReportActivity.class); //現在,跳轉目標
            intent.putExtra("number",user_number);
            if(from.equals("Mission")) intent.putExtra("from","Mission");
                else intent.putExtra("from","Main");
            startActivity(intent);
        });

        self = findViewById(R.id.self);
        self.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(this , PersonalActivity.class); //現在,跳轉目標
            intent.putExtra("name",user_name);
            intent.putExtra("number",user_number);
            startActivity(intent);
        });

        String nowDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        today = nowDate.split("-");
        calendar = Calendar.getInstance();
        calendarView = findViewById(R.id.calendarView);
        setDate(Integer.parseInt(today[0]),Integer.parseInt(today[1]),Integer.parseInt(today[2]));
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
                setDate(year,month + 1,dayOfMonth);
            }
        });

        write = findViewById(R.id.write);
        write.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(this , RecordActivity.class); //現在,跳轉目標
            String date = new SimpleDateFormat("yyyy-MM-dd").format(calendarView.getDate());
            intent.putExtra("date",date);
            intent.putExtra("week",getWeek());
            intent.putExtra("mood_pic",0);
            intent.putExtra("from","Main");
            intent.putExtra("user_number",user_number);
            startActivity(intent);
        });

        userName = findViewById(R.id.name);
        userName.setText(user_name);
        date = findViewById(R.id.today);
        String s = today[0]+"."+today[1]+"."+today[2];
        date.setText(s);

        if(from.equals("Mission")){
            try {
                getTXTMissionCondition();
                // delay 1 second
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if(line_id == null || line_id.equals("null") || line_id.isEmpty()){
                showDialog("Line");
            } else {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("text/plain"); // 限制文件类型为.txt文件
                startActivityForResult(intent, PICK_TXT_FILE_REQUEST);
            }
        }

        mood = findViewById(R.id.mood);
        double mood_now = getMoodNow();
        System.out.println("mood_now = "+mood_now);
        if(mood_now != -1) mood.setImageDrawable(moodPics.getMoodPic(mood_now));
    }

    private double getMoodNow() {
        double m = 0;
        int num = 0;
        int change_counnt = 0;
        try {
            getFBmood();
            getLineMood();
            getIGMood();
            getDiaryMood();
            if(txt_score > 0) {
                m += txt_score;
                change_counnt++;
                num++;
            }
            if(fb_score > 0) {
                m += fb_score;
                change_counnt++;
                num++;
            }
            if(ins_score > 0) {
                m += ins_score;
                change_counnt++;
                num++;
            }
            if(post_score > 0) {
                m += post_score;
                change_counnt++;
                num++;
            }
            if(m > 0 && num > 0) m = m / num;
        }catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(this, "表情更新失敗", Toast.LENGTH_SHORT).show();
        }
        //System.out.println("現在心情："+m);
        if(change_counnt == 0) m = -1;
        return m;
    }

    private double changeMoodNow() {
        double m = 0;
        int num = 0;
        if(txt_score > 0) {
            m += txt_score;
            num++;
        }
        if(fb_score > 0) {
            m += fb_score;
            num++;
        }
        if(ins_score > 0) {
            m += ins_score;
            num++;
        }
        if(post_score > 0) {
            m += post_score;
            num++;
        }
        if(m > 0 && num > 0) m = m / num;
        if(m == 0) m = 0.5;
        return m;
    }

    public void getDiaryMood() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String date_text = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                    String sql = "SELECT * FROM \"diary\" WHERE user_number = "+user_number+ " AND diary_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    int post_count = 0;
                    double sores = 0;
                    int i = 0;
                    while (resultSet.next()) {
                        if(i == 0) post_score = 0;
                        post_count++;
                        sores += Double.valueOf(resultSet.getString("diary_score"));
                        i++;
                    }

                    if(post_count > 0){ //今天有寫日記
                        System.out.println("兼天有寫日記");
                        post_score = sores / post_count;
                    }else post_score = -1;

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void setDate(int year, int month, int dayOfMonth){
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        long time = calendar.getTimeInMillis();
        calendarView.setDate(time);
    }

    public String getWeek(){
        String[] week_ch = {"(一)","(二)","(三)","(四)","(五)","(六)","(日)"};
        int week = calendar.get(Calendar.DAY_OF_WEEK);
        int index = 0;
        if(week == 1){ //星期日
            index = 6;
        }else{
            index = week - 2;
        }
        return week_ch[index];
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_TXT_FILE_REQUEST && resultCode == RESULT_OK && data != null){
            Uri selectedFileUri = data.getData();
            FileInputStream fileInputStream = null;
            Context context = this;
            InputStream inputStream;
            try {
                inputStream = uriToInputStream(context, selectedFileUri);

                // 根据需要，将 InputStream 转换为 FileInputStream 或其他类型
                String tempFile = null;
                fileInputStream = (inputStream instanceof FileInputStream) ? (FileInputStream) inputStream : new FileInputStream(tempFile);

                // 在这里使用 fileInputStream
            } catch (IOException e) {
                e.printStackTrace();
            }

            dbread_method caller = new dbread_method();
            try {
                caller.dbread_method_api(line_id, fileInputStream,user_number);
                System.out.println("user_number = "+user_number);
                if(caller.NameCorrect()){
                    UpdateMissionCondition(0);
                    Toast.makeText(this, "分析成功", Toast.LENGTH_SHORT).show();
                }else Toast.makeText(MainActivity.this, "line名稱輸入錯誤，請再次確認", Toast.LENGTH_SHORT).show();
            } catch (InterruptedException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "檔案上傳失敗", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showDialog(String type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        EditText editText = new EditText(MainActivity.this); //final一個editText
        builder.setView(editText);
        switch (type){
            case "Line" : builder.setTitle("尚未輸入Line名稱，請輸入："); break;
            case "FB" : builder.setTitle("尚未輸入FaceBook連結，請輸入："); break;
            case "IG" : builder.setTitle("尚未輸入Instagram連結，請輸入："); break;
        }

        builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    updateUser(type, editText.getText().toString());
                    switch (type){
                        case "Line" : line_id = editText.getText().toString(); break;
                        case "FB" : fb_link = editText.getText().toString(); break;
                        case "IG" : ins_link = editText.getText().toString(); break;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Toast.makeText(MainActivity.this, "輸入成功", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }

    private void showHouseDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.house_image);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        ImageView close = dialog.findViewById(R.id.close);
        ImageView house = dialog.findViewById(R.id.house);

        String nowDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        // 定义服务器上图像的URL
        String imageUrl = "http://140.127.220.89/image/house/user"+user_number+"_"+nowDate+"_house.png";
        // 使用 Glide 加载图像
        Glide.with(this)
                .load(imageUrl)
                .into(house);

        close.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    public void updateUser(String type, String link) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String column = "";
                    switch (type){
                        case "Line" : column = "line_id"; break;
                        case "FB" : column = "fb_link"; break;
                        case "IG" : column = "ins_link"; break;
                    }
                    String sql = "UPDATE \"user\" SET " + column + " = '" + link + "' WHERE user_number = " + user_number;
                    System.out.println(sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getLineMood() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
//                    String date_text = "2023/10/04";
                    String sql = "SELECT * FROM \"txt\" WHERE user_number = "+user_number+ " AND txt_date = to_date('" +date_text+ "', 'YYYY-MM-DD') AND txt_score != -1";
                    System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    int txt_count = 0;
                    double sores = 0;
                    int i = 0;
                    while (resultSet.next()) {
                        if(i == 0) txt_score = 0;
                        txt_count++;
                        if(!resultSet.getString("txt_score").equals("null") && resultSet.getString("txt_score") != null){
                            System.out.println("txt_score = "+resultSet.getString("txt_score"));
                            sores += Double.valueOf(resultSet.getString("txt_score"));
                        }
                        i++;
                    }

                    System.out.println("txt_count = "+txt_count);
                    if(txt_count > 0){ //今天有上傳聊天紀錄
                        if(txt_count > txt_num) ins_num = txt_count;
                        txt_score = sores / ins_num;
                        mood_line.setImageDrawable(moodPics.getMoodPic(txt_score));
                    }else {
                        txt_score = -1;
                        mood_line.setImageDrawable(getResources().getDrawable(R.drawable.question));
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getFBmood() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String nowDate = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT * FROM \"facebook\" WHERE user_number = "+user_number+" AND fb_post_date = to_date('"+nowDate+"', 'YYYY-MM-DD')";
                    //System.out.println(sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    int fb_count = 0;
                    double sores = 0;
                    int i = 0;
                    while (resultSet.next()) {
                        if(i == 0) fb_score = 0;
                        fb_count++;
                        sores += Double.valueOf(resultSet.getString("fb_post_scores"));
                        i++;
                    }

                    if(fb_count > 0){ //今天有發文
                        if(fb_count > fb_num) fb_num = fb_count;
                        fb_score = sores / fb_num;
                        mood_fb.setImageDrawable(moodPics.getMoodPic(fb_score));
                    }else{
                        fb_score = -1;
                        mood_fb.setImageDrawable(getResources().getDrawable(R.drawable.question));
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getuser() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"user\" WHERE user_number = "+user_number;
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        user_name = resultSet.getString("user_name");
                        line_id = resultSet.getString("line_id");
                        fb_link = resultSet.getString("fb_link");
                        ins_link = resultSet.getString("ins_link");
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }


    public InputStream uriToInputStream(Context context, Uri uri) throws IOException {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);

        if (inputStream != null) {
            return inputStream;
        } else {
            throw new IOException("Failed to open InputStream from Uri");
        }
    }

    public void getTXTMissionCondition() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT count(*) AS num FROM \"txt\" WHERE user_number = "+user_number+ " AND txt_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        txt_num = Integer.parseInt(resultSet.getString("num"));
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getFBMissionCondition() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT count(*) AS num FROM \"facebook\" WHERE user_number = "+user_number+ " AND fb_post_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        fb_num = Integer.parseInt(resultSet.getString("num"));
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getIGMood() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT * FROM \"instagram\" WHERE user_number = "+user_number+ " AND ins_post_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    int ig_count = 0;
                    double sores = 0;
                    int i = 0;
                    while (resultSet.next()) {
                        if(i == 0) ins_score = 0;
                        ig_count++;
                        sores += Double.valueOf(resultSet.getString("ins_post_scores"));
                        i++;
                    }

                    if(ig_count > 0){ //今天有發文
                        if(ig_count > ins_num) ins_num = ig_count;
                        ins_score = sores / ins_num;
                        mood_ig.setImageDrawable(moodPics.getMoodPic(ins_score));
                    }else {
                        ins_score = -1;
                        mood_ig.setImageDrawable(getResources().getDrawable(R.drawable.question));
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void UpdateMissionCondition(int type) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String set_sql = "";
                    switch (type){
                        case 0: //聊天紀錄
                            txt_num++;
                            set_sql = "dm_txt = "+txt_num;
                            break;
                        case 1: //fb
                            break;
                        case 2: //ins
                            break;
                    }

                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "UPDATE \"daily_mission\" SET "+set_sql+" WHERE user_number = "+user_number+ " AND dm_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    if(txt_num >= 3) {
                        MissionActivity.changeMissionCondition(2, 3);
                    }else {
                        if(from.equals("Mission")) MissionActivity.changeMissionCondition(2, txt_num);
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    static void changeUserName(String name){
        userName.setText(name);
        user_name = name;
    }

    static void changeLink(String[] text){ //0為line_id, 1為fb_link, 2為ins_link
        line_id = text[0];
        fb_link = text[1];
        ins_link = text[2];
    }

    static void changeNowMood() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String nowDate = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT * FROM \"facebook\" WHERE user_number = "+user_number+" AND fb_post_date = to_date('"+nowDate+"', 'YYYY-MM-DD')";
                    //System.out.println(sql);
                    ResultSet resultSet = statement.executeQuery(sql);
                    int fb_count = 0;
                    double sores = 0;
                    int i = 0;
                    while (resultSet.next()) {
                        if(i == 0) fb_score = 0;
                        fb_count++;
                        sores += Integer.parseInt(resultSet.getString("fb_post_scores"));
                        i++;
                    }
                    if(fb_count > 0){ //今天有發文
                        if(fb_count > fb_num) fb_num = fb_count;
                        fb_score = sores / fb_num;
                    }else{
                        fb_score = -1;
                    }



                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    sql = "SELECT * FROM \"txt\" WHERE user_number = "+user_number+ " AND txt_date = to_date('" +date_text+ "', 'YYYY-MM-DD') AND txt_score != -1";
                    System.out.println("sql為："+sql);
                    resultSet = statement.executeQuery(sql);
                    int txt_count = 0;
                    sores = 0;
                    i = 0;
                    while (resultSet.next()) {
                        if(i == 0) txt_score = 0;
                        txt_count++;
                        if(!resultSet.getString("txt_score").equals("null") && resultSet.getString("txt_score") != null){
                            System.out.println("txt_score = "+resultSet.getString("txt_score"));
                            sores += Double.valueOf(resultSet.getString("txt_score"));
                        }
                        i++;
                    }
                    System.out.println("txt_count = "+txt_count);
                    if(txt_count > 0){ //今天有上傳聊天紀錄
                        if(txt_count > txt_num) ins_num = txt_count;
                        txt_score = sores / ins_num;
                    }else {
                        txt_score = -1;
                    }


                    sql = "SELECT * FROM \"instagram\" WHERE user_number = "+user_number+ " AND ins_post_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    System.out.println("sql為："+sql);
                    resultSet = statement.executeQuery(sql);
                    int ig_count = 0;
                    sores = 0;
                    i = 0;
                    while (resultSet.next()) {
                        if(i == 0) ins_score = 0;
                        ig_count++;
                        sores += Double.valueOf(resultSet.getString("ins_post_scores"));
                        i++;
                    }
                    if(ig_count > 0){ //今天有發文
                        if(ig_count > ins_num) ins_num = ig_count;
                        ins_score = sores / ins_num;
                    }else {
                        ins_score = -1;
                    }


                    sql = "SELECT * FROM \"diary\" WHERE user_number = "+user_number+ " AND diary_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    System.out.println("sql為："+sql);
                    resultSet = statement.executeQuery(sql);
                    int post_count = 0;
                    sores = 0;
                    i = 0;
                    while (resultSet.next()) {
                        if(i == 0) post_score = 0;
                        post_count++;
                        sores += Double.valueOf(resultSet.getString("diary_score"));
                        i++;
                    }
                    if(post_count > 0){ //今天有寫日記
                        post_score = sores / post_count;
                    }else post_score = -1;


                    resultSet.close();
                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();


        double m = 0;
        int num = 0;
        int change_counnt = 0;
        if(txt_score > 0) {
            m += txt_score;
            change_counnt++;
            num++;
        }
        if(fb_score > 0) {
            m += fb_score;
            change_counnt++;
            num++;
        }
        if(ins_score > 0) {
            m += ins_score;
            change_counnt++;
            num++;
        }
        if(post_score > 0) {
            m += post_score;
            change_counnt++;
            num++;
        }
        if(m > 0 && num > 0) m = m / num;
        //System.out.println("現在心情："+m);

        mood.setImageDrawable(moodPics.getMoodPic(m));
        if(change_counnt == 0) mood.setImageDrawable(question);

        for(int i = 0 ; i< ActivityCollector.activities.size() ; i++){
            if(ActivityCollector.activities.get(i) instanceof PersonalActivity){
                PersonalActivity.mood.setImageDrawable(moodPics.getMoodPic(m));
                if(change_counnt == 0) PersonalActivity.mood.setImageDrawable(question);
            }
        }
    }
}