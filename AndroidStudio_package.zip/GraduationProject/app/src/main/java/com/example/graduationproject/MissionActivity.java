package com.example.graduationproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import static java.time.DayOfWeek.SATURDAY;
import static java.time.DayOfWeek.SUNDAY;
import static java.time.temporal.TemporalAdjusters.next;
import static java.time.temporal.TemporalAdjusters.previous;

public class MissionActivity extends AppCompatActivity {
    Context context;
    private int user_number;
    private String[] today;
    private int today_index; //今天在這個禮拜(this_week)的索引值
    private List<LocalDate> this_week;
    String[] week_text = {"sunday","monday","tuesday","wednesday","thursday","friday","saturday"};

    ImageView back;
    @SuppressLint("StaticFieldLeak")
    static TextView diary;
    @SuppressLint("StaticFieldLeak")
    static TextView line_txt;
    TextView[] months = new TextView[7];
    TextView[] days = new TextView[7];
    TextView[] log_ins = new TextView[7];
    static ImageView[] mission_btns = new ImageView[4];
    static int[] mission_btns_condition = new int[4]; //0代表還沒完成, 1代表已完成
    static boolean[] mission_conditions_boolean = new boolean[4];
    boolean[] log_in_conditions = new boolean[7];
    int[] mission_conditions_int = new int[2]; //0為自定義分類的貼文, 1為整日貼文
    static Drawable[] mission_btn_pics = new Drawable[2];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission);
        ActivityCollector.addActivity(this);

        context = this;

        Intent i = getIntent();
        user_number = i.getIntExtra("number" , 0);

        back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            ActivityCollector.removeActivity(this);
            finish();
        });

        diary = findViewById(R.id.diary);
        line_txt = findViewById(R.id.line_txt);

        months[0] = findViewById(R.id.month7);
        months[1] = findViewById(R.id.month1);
        months[2] = findViewById(R.id.month2);
        months[3] = findViewById(R.id.month3);
        months[4] = findViewById(R.id.month4);
        months[5] = findViewById(R.id.month5);
        months[6] = findViewById(R.id.month6);

        days[0] = findViewById(R.id.day7);
        days[1] = findViewById(R.id.day1);
        days[2] = findViewById(R.id.day2);
        days[3] = findViewById(R.id.day3);
        days[4] = findViewById(R.id.day4);
        days[5] = findViewById(R.id.day5);
        days[6] = findViewById(R.id.day6);

        log_ins[0] = findViewById(R.id.sign_in7);
        log_ins[1] = findViewById(R.id.sign_in1);
        log_ins[2] = findViewById(R.id.sign_in2);
        log_ins[3] = findViewById(R.id.sign_in3);
        log_ins[4] = findViewById(R.id.sign_in4);
        log_ins[5] = findViewById(R.id.sign_in5);
        log_ins[6] = findViewById(R.id.sign_in6);

        @SuppressLint("SimpleDateFormat") String nowdate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        today = nowdate.split("-");
        setDateRangeList(nowdate);
        try {
            getMissionCondition(nowdate);
            getLogInCondition();
            setLogInBtn();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        mission_btns[0] = findViewById(R.id.imageView); //自定義分類日記
        mission_btns[0].setOnClickListener(view -> {
            if(mission_conditions_int[0] < 3){
                Intent intent = new Intent();
                intent.setClass(this , RecordActivity.class); //現在,跳轉目標
                intent.putExtra("user_number",user_number);
                intent.putExtra("week",getWeek());
                intent.putExtra("from","Mission");
                intent.putExtra("date",nowdate);
                startActivity(intent);
            }
        });
        mission_btns[1] = findViewById(R.id.imageView2); //整日日記
        mission_btns[1].setOnClickListener(view -> {
            if(!mission_conditions_boolean[0]){
                Intent intent = new Intent();
                intent.setClass(this , RecordActivity.class); //現在,跳轉目標
                intent.putExtra("user_number",user_number);
                intent.putExtra("from","Mission");
                intent.putExtra("week",getWeek());
                intent.putExtra("date",nowdate);
                startActivity(intent);
            }
        });
        mission_btns[2] = findViewById(R.id.imageView3); //匯入聊天紀錄
        mission_btns[2].setOnClickListener(view -> {
            if(mission_conditions_int[1] < 3){
                Intent intent = new Intent();
                intent.setClass(this , MainActivity.class); //現在,跳轉目標
                intent.putExtra("user_number",user_number);
                intent.putExtra("from","Mission");
                startActivity(intent);
            }
        });

        mission_btns[3] = findViewById(R.id.imageView4); //查看報表
        mission_btns[3].setOnClickListener(view -> {
            if(!mission_conditions_boolean[1]){
                Intent intent = new Intent();
                intent.setClass(this , ReportActivity.class); //現在,跳轉目標
                intent.putExtra("number",user_number);
                intent.putExtra("from","Mission");
                startActivity(intent);
            }
        });
        setMissionBtns();
    }

    void setLogInBtn(){
        for(int i = 0 ; i < this_week.size() ; i++){
            changeSignIn(2,i);
            if(this_week.get(i).getMonthValue() >= Integer.parseInt(today[1])){
                if(this_week.get(i).getDayOfMonth() > Integer.parseInt(today[2])){ //以後的
                    changeSignIn(0,i);
                }else if(this_week.get(i).getDayOfMonth() == Integer.parseInt(today[2])){ //今天
                    today_index = i;
                    if(log_in_conditions[i]){
                        changeSignIn(1,i);
                    }
                }else{ //之前的
                    if(log_in_conditions[i]){
                        changeSignIn(1,i);
                    }else{
                        changeSignIn(0,i);
                    }
                }

            }else{ //之前的
                if(log_in_conditions[i]){
                    changeSignIn(1,i);
                }else{
                    changeSignIn(0,i);
                }
            }

            int index = i;
            log_ins[index].setOnClickListener(view -> {
                if(today_index == index){
                    if(!log_in_conditions[index]){
                        try {
                            UpdateLogInCondition(index);
                            changeSignIn(1,index);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        }
    }

    void changeSignIn(int type, int index){
        switch (type){
            case 0: //尚不能簽到(不出現)
                log_ins[index].setVisibility(View.GONE);
                break;

            case 1: //已簽到(灰色)
                log_ins[index].setVisibility(View.VISIBLE);
                log_ins[index].setText("已簽到");
                log_ins[index].setTextColor(this.getResources().getColor(R.color.grey));
                log_ins[index].setTextSize(18);
                break;

            case 2: //未簽到(橘色)
                log_ins[index].setVisibility(View.VISIBLE);
                log_ins[index].setText("簽到");
                log_ins[index].setTextColor(this.getResources().getColor(R.color.orange));
                log_ins[index].setTextSize(20);
                break;
        }
    }

    List<LocalDate> getDateRangeList(String dateString) {
        LocalDate date = LocalDate.parse(dateString);
        int year = date.getYear();
        int month = date.getMonthValue();
        int day = date.getDayOfMonth();

        LocalDate today = LocalDate.of(year, month, day);
        LocalDate pastSunday = today.with(previous(SUNDAY));
        LocalDate nextSaturday = today.with(next(SATURDAY));
        LocalDate startDay;
        LocalDate endDay;

        if (date.getDayOfWeek() == SUNDAY) {
            startDay = today;
            endDay = nextSaturday;
        }else if ((date.getDayOfWeek() == SATURDAY)){
            startDay = pastSunday;
            endDay = today;
        }else{
            startDay = pastSunday;
            endDay = nextSaturday;
        }

        List<LocalDate> dateArray = new ArrayList<>();
        LocalDate currentDate = startDay;
        while (!currentDate.isAfter(endDay)) {
            dateArray.add(currentDate);
            currentDate = currentDate.plusDays(1);
        }
        return dateArray;
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    void setMissionBtns() {
        mission_btn_pics[0] = getResources().getDrawable(R.drawable.go_to_receive); //還沒完成(去完成)
        mission_btn_pics[1] = getResources().getDrawable(R.drawable.received); //已完成

        for (int i = 0 ; i < mission_btns.length ; i++){
            mission_btns[i].setImageDrawable(mission_btn_pics[0]);
            mission_btns_condition[i] = 0;
        }

        if(mission_conditions_int[0] >= 3){ //
            mission_btns[0].setImageDrawable(mission_btn_pics[1]);
            diary.setText("寫自訂分類日記(3/3)");
        }else diary.setText("寫自訂分類日記("+mission_conditions_int[0]+"/3)");

        if(mission_conditions_int[1] >= 3){
            mission_btns[2].setImageDrawable(mission_btn_pics[1]);
            line_txt.setText("匯入一個聊天紀錄(3/3)");
        }else line_txt.setText("匯入一個聊天紀錄("+mission_conditions_int[1]+"/3)");

        if(mission_conditions_boolean[0]) mission_btns[1].setImageDrawable(mission_btn_pics[1]);
        for(int i = 1 ; i < mission_conditions_boolean.length ; i++){
            if(mission_conditions_boolean[i]){
                mission_btns[i+2].setImageDrawable(mission_btn_pics[1]);
            }
        }
    }

    void setDateRangeList(String today){
        this_week = getDateRangeList(today);
        for(int i = 0 ; i < months.length ; i++){
            months[i].setText(String.valueOf(this_week.get(i).getMonthValue()));
            days[i].setText(String.valueOf(this_week.get(i).getDayOfMonth()));
        }
    }

    public void getMissionCondition(String today) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String[] d = today.split("-");
                    String date_text = d[0]+"/"+d[1]+"/"+d[2];
                    String sql = "SELECT * FROM \"daily_mission\" WHERE user_number = "+user_number+ " AND dm_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    int count = 0;
                    while (resultSet.next()) {
                        for(int i = 0 ; i < mission_conditions_boolean.length ; i++){
                            mission_conditions_boolean[i] = false;
                        }
                        if(resultSet.getString("dm_diary").equals("t")) mission_conditions_boolean[0] = true;
                        if(resultSet.getString("dm_report").equals("t")) mission_conditions_boolean[1] = true;

                        mission_conditions_int[0] = resultSet.getInt("dm_daily_diary");
                        mission_conditions_int[1] = resultSet.getInt("dm_txt");
                        System.out.println("dm_txt = "+mission_conditions_int[1]);
                        count++;
                    }

                    if (count == 0){
                        insertDailyMission();
                        mission_conditions_boolean[0] = false;
                        mission_conditions_boolean[1] = false;
                        mission_conditions_int[0] = 0;
                        mission_conditions_int[1] = 0;
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException | InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getLogInCondition() throws InterruptedException {
        Thread t = new Thread(() -> {
            String host = "140.127.220.89"; // IP
            int port = 5432; //
            String databaseName = "postgres"; //
            String user = "postgres"; //
            String password = "CrownRu"; //

            //
            Connection connection = null;

            try {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);

                String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                // PostgreSQL JDBC
                Class.forName("org.postgresql.Driver");

                // �s��
                connection = DriverManager.getConnection(url, user, password);

                // ����SQL
                Statement statement = connection.createStatement();


                String sunday_date = this_week.get(0).getYear()+"/"+this_week.get(0).getMonthValue()+"/"+this_week.get(0).getDayOfMonth();
                String sql = "SELECT * FROM \"week_login_mission\" WHERE user_number = "+user_number+ " AND sunday_date = to_date('" +sunday_date+ "', 'YYYY-MM-DD')";
                //System.out.println("sql為："+sql);
                ResultSet resultSet = statement.executeQuery(sql);

                if (resultSet.next()) {
                    for(int i = 0 ; i < log_in_conditions.length ; i++){
                        log_in_conditions[i] = false;
                        if(resultSet.getString(week_text[i]).equals("t")) log_in_conditions[i] = true;
                    }
                }else{
                    insertLogInCondition();
                    System.out.println("insertLogInCondition()");
                }

                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("SQLException");
            } catch (ClassNotFoundException | InterruptedException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (connection != null) {
                        connection.close();
                    }else{
                        System.out.println("connection = null");
                        Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });

        t.start();
        t.join();
    }

    public void insertLogInCondition() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String sunday_date = this_week.get(0).getYear()+"/"+this_week.get(0).getMonthValue()+"/"+this_week.get(0).getDayOfMonth();
                    String sql = "INSERT INTO \"week_login_mission\" (\"user_number\", \"sunday_date\", \"monday\", \"tuesday\", \"wednesday\", \"thursday\", \"friday\", \"saturday\", \"sunday\") VALUES ("+user_number+ ", to_date('" +sunday_date+ "\', \'YYYY-MM-DD\'), false, false, false, false, false, false, false)";
                    Arrays.fill(log_in_conditions, false);
                    //System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void UpdateLogInCondition(int index) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String sunday_date = this_week.get(0).getYear()+"/"+this_week.get(0).getMonthValue()+"/"+this_week.get(0).getDayOfMonth();
                    String sql = "UPDATE \"week_login_mission\" SET "+week_text[index]+" = true WHERE user_number = "+user_number+" AND sunday_date = to_date(\'" +sunday_date+ "\', \'YYYY-MM-DD\')";
                    //System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    static void changeMissionCondition(int index){
        mission_conditions_boolean[index] = true;
        mission_btns_condition[index] = 1;
        mission_btns[index].setImageDrawable(mission_btn_pics[1]);
    }

    static void changeMissionCondition(int index, int num){
        mission_conditions_boolean[index] = true;
        mission_btns_condition[index] = 1;
        if(index == 2){ //匯入聊天紀錄
            if(num >= 3){
                line_txt.setText("匯入一個聊天紀錄3/3)");
                mission_btns[index].setImageDrawable(mission_btn_pics[1]);
            }else{
                line_txt.setText("匯入一個聊天紀錄("+num+"/3)");
            }
        }else{ //自訂分類日記
            if(num >= 3){
                diary.setText("寫自訂分類日記(3/3)");
                mission_btns[index].setImageDrawable(mission_btn_pics[1]);
            }else {
                diary.setText("寫自訂分類日記("+num+"/3)");
            }
        }
    }

    public String getWeek(){
        String[] week_ch = {"(一)","(二)","(三)","(四)","(五)","(六)","(日)"};
        int week = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
        int index = 0;
        if(week == 1){ //星期日
            index = 6;
        }else{
            index = week - 2;
        }
        return week_ch[index];
    }

    public void insertDailyMission() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String nowdate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                    String sql = "INSERT INTO \"daily_mission\" (\"user_number\", \"dm_login\", \"dm_daily_diary\", \"dm_diary\", \"dm_txt\", \"dm_report\", \"dm_facebook\", \"dm_instagram\", \"dm_date\") VALUES ("+user_number+", false, 0, false, 0, false, false, false, to_date(\'"+nowdate+"\', \'YYYY-MM-DD\'))";
                    //System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }
}