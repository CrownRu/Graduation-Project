package com.example.graduationproject;

import android.os.StrictMode;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.PreparedStatement;
public class dbread_method {
    private int count = 0;

    public void dbread_method_api(String targetPerson,FileInputStream filename, int user_num) throws InterruptedException {
        System.out.println("用戶line名稱:"+targetPerson);
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89";
                int port = 5432;
                String databaseName = "postgres";
                String user = "postgres";
                String password = "CrownRu";
                Connection connection = null;
                PreparedStatement preparedStatement = null;
                String currentDate = null; //  s   e
                int lineCount = 0;
                List<String> targetPersonMessages = new ArrayList<>(); //  s?  ? H?   C @ y?
                try{
                    String line;
                    String currentMessage = "";
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;
                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");
                    connection = DriverManager.getConnection(url, user, password);
                    //System.out.println("filename = "+filename);
                    BufferedReader br = new BufferedReader(new InputStreamReader(filename, "UTF-8"));
                    //System.out.println("date line:");
                    while ((line = br.readLine()) != null) {
                        lineCount++;
                        line = line.trim();
                        if (lineCount <= 2) {
                            continue;
                        }
                        if(line.isEmpty()){
                            continue;
                        }
                        line = line.replaceAll("\\t", " ").trim();
                        String[] sentence_spilit=line.split(" ");

                        Pattern datePattern = Pattern.compile("\\d{4}/\\d{2}/\\d{2},\\s+\\w+");  //    榡
                        Matcher dateMatcher = datePattern.matcher(line);
                        if (dateMatcher.find()) {
                            currentDate = dateMatcher.group().replaceAll(",\\s+\\w+", ""); //             A h   r? ","
                            //System.out.println("date line:"+currentDate);

                        } else if (line.contains(targetPerson) && targetPerson.equals(sentence_spilit[1])) {
                            if (line.substring(line.indexOf(targetPerson)).trim().startsWith(targetPerson)){
                                String time = line.substring(0, 5); //     ??
                                String message = line.substring(line.indexOf(targetPerson) + targetPerson.length()).trim();
                                System.out.println(line.substring(line.indexOf(targetPerson)).trim());
                                count++;
                                currentMessage = currentDate + " " + time + " " + message; //  ۫ ? e
                                targetPersonMessages.add(currentMessage);
                            }
                        } else if (!currentMessage.isEmpty()) {
                            Pattern spPattern = Pattern.compile("(\\d{2}:\\d{2})[\\t ]+(.*?)[\\t ]+(.*)");
                            Matcher matcher = spPattern.matcher(line);
                            if (matcher.matches()){
                                continue;
                            }
                            targetPersonMessages.set(targetPersonMessages.size() - 1, targetPersonMessages.get(targetPersonMessages.size() - 1) + line);
                        }
                    }
                    String insertSQL = "INSERT INTO \"txt\" (\"txt_content\", \"txt_date\", \"txt_time\", \"user_number\") VALUES (?, to_date(?, 'YYYY-MM-DD'), ?::time)ON CONFLICT (\"txt_content\", \"txt_date\", \"txt_time\", "+user_num+") DO NOTHING";
                    preparedStatement = connection.prepareStatement(insertSQL);
                    for (String onemessage : targetPersonMessages) {
                        String[] parts = onemessage.split(" ", 3); //    Τ   B?? M    ? e
                        String date = parts[0];
                        String time = parts[1];
                        String content = parts[2];
                        preparedStatement.setString(1, content);
                        preparedStatement.setString(2, date);
                        preparedStatement.setString(3, time);
                        preparedStatement.executeUpdate();
                    }
                    System.out.println("end");
                    br.close();
                }catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    try {
                        if (preparedStatement != null) {
                            preparedStatement.close();
                        }
                        if (connection != null) {
                            connection.close();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public boolean NameCorrect(){
        System.out.println(count);
        if (count > 0){
            count = 0;
            return true;
        }
        return false;
    }
}
