package com.example.graduationproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PersonalActivity extends AppCompatActivity {
    Context context;
    static MoodPics moodPics;
    RecyclerView mRecyclerView;
    LinearLayoutManager linearLayoutManager;
    static MyListAdapter myListAdapter;
    private LinearLayout parent;

    static String user_name;
    private int user_number;
    private int userPic;
    private Drawable[] user_pics = new Drawable[1];

    ImageView back;
    ImageButton mission;
    ImageButton setting;
    static TextView name;
    static ImageView mood;

    private ArrayList<PostData> postdata = new ArrayList<>();
    private boolean finished = false;
    private boolean sorted = false;
    private int delected_diary = 0;
    private int delected_diary_image = 0;

    private ArrayList<String> post_pics = new ArrayList<>();

    double post_score = -1;
    double txt_score = -1;
    double fb_score = -1;
    double ins_score = -1;
    int txt_num;
    int fb_num;
    int ins_num;


    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal);
        ActivityCollector.addActivity(this);

        context = this;
        moodPics = new MoodPics(this);

        Intent i = getIntent();
        user_name = i.getStringExtra("name");
        user_number = i.getIntExtra("number" , 0);
        userPic = i.getIntExtra("pic",0);
        user_pics[0] = getResources().getDrawable(R.drawable.user);

        //取得資料
        try {
            getpost(user_number);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        parent = findViewById(R.id.LinearLayout);

        back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            ActivityCollector.removeActivity(this);
            finish();
        });

        mission = findViewById(R.id.mission);
        mission.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(this , MissionActivity.class); //現在,跳轉目標
            intent.putExtra("number",user_number);
            startActivity(intent);
        });

        setting = findViewById(R.id.setting);
        setting.setOnClickListener(view -> {
            Intent intent = new Intent(this, PersonalEditActivity.class); //現在,跳轉目標
            intent.putExtra("number",user_number);
            intent.putExtra("user_name",user_name);
            startActivityForResult(intent, 0);
        });

        name = findViewById(R.id.name);
        name.setText(user_name);

        mood = findViewById(R.id.mood);

        //設置貼文RecycleView
        mRecyclerView = findViewById(R.id.recycleview);
        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this){
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        });
        myListAdapter = new PersonalActivity.MyListAdapter(this);
        mRecyclerView.setAdapter(myListAdapter);

        try {
            getNowMood();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    class MyListAdapter extends RecyclerView.Adapter<PersonalActivity.MyListAdapter.ViewHolder>{
        PersonalActivity thisActivity;
        private RecyclerView.RecycledViewPool viewPool = new RecyclerView.RecycledViewPool();

        class ViewHolder extends RecyclerView.ViewHolder{
            private int postnum; //該貼文的編號
            private TextView userName,postDate,context,classification;
            private ImageView userPic;
            private LinearLayout wholeLayout;
            private View mView;
            private RecyclerView recyclerView;
            private int picnum; //該貼文的圖片數量
            private NestedScrollView nestedScrollView;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                userPic = itemView.findViewById(R.id.pic);
                userName = itemView.findViewById(R.id.name);
                postDate = itemView.findViewById(R.id.time);
                context = itemView.findViewById(R.id.context);
                classification = itemView.findViewById(R.id.classification);
                wholeLayout = itemView.findViewById(R.id.layout);
                recyclerView  = itemView.findViewById(R.id.recycleview_pic);
                nestedScrollView  = itemView.findViewById(R.id.nestedScrollView);
                mView  = itemView;
            }
        }

        public MyListAdapter(PersonalActivity a) {
            super();
            thisActivity = a;
        }

        @NonNull
        @Override
        public MyListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //原本返回type為RecyclerView.ViewHolder
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.recycle_item,parent,false);
            return new MyListAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final MyListAdapter.ViewHolder holder, int position) { //position從0開始
            String content = "載入失敗";
            String date = "載入失敗";
            String classification_text = "整日日記";

            while (!finished){
                System.out.println("還沒結束");
            }
            while (!sorted){
                System.out.println("還沒排序好");
                sort();
            }
            for (int i = 0 ; i < postdata.size() ; i++){
                //System.out.println("第"+i+"個postdata的postdata = "+postdata.get(i).Number+"  內容為"+postdata.get(i).Context+"  日期為"+postdata.get(i).Date);
                if(i == holder.getAdapterPosition()){
                    content = postdata.get(i).Context;
                    date = postdata.get(i).Date;
                    classification_text = postdata.get(i).classification;
                    holder.postnum = postdata.get(i).Number;
                    holder.picnum = postdata.get(i).PictureNum;
                    //System.out.println("第"+holder.getAdapterPosition()+"個貼文 postdata = "+postdata.get(i).Number+"  內容為"+content+"  日期為"+date);
                }
            }
            holder.userPic.setImageDrawable(user_pics[userPic]);
            holder.userName.setText(user_name);
            holder.postDate.setText(date);
            holder.classification.setText("分類："+classification_text);
            holder.context.setText(content);

            holder.mView.setOnLongClickListener((v)->{
                try {
                    deleteDiary(user_number, holder.postnum, holder.picnum);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(delected_diary == 1){
                    myListAdapter.notifyItemRemoved(holder.getAdapterPosition());
                    try {
                        MainActivity.changeNowMood();
                        getNowMood();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Toast.makeText(context, "主頁心情修改失敗", Toast.LENGTH_SHORT).show();
                    }
                    if(myListAdapter.getItemCount() == 0){
                        mRecyclerView.setVisibility(View.GONE);
                    }
                    Toast.makeText(getApplicationContext(), "刪除成功", Toast.LENGTH_SHORT).show();
                    delected_diary = 0;
                }else{
                    Toast.makeText(getApplicationContext(), "刪除失敗", Toast.LENGTH_SHORT).show();
                }


                return true;
            });

            holder.wholeLayout.setOnClickListener((v)->{
                Intent intent = new Intent();
                intent.setClass(PersonalActivity.this , PostActivity.class); //現在,跳轉目標
                intent.putExtra("user_number",user_number);
                intent.putExtra("user_name",user_name);
                intent.putExtra("post_number",holder.postnum);
                startActivity(intent);
            });

            holder.recyclerView.setOnClickListener((v)->{
                Intent intent = new Intent();
                intent.setClass(PersonalActivity.this , PostActivity.class); //現在,跳轉目標
                intent.putExtra("user_number",user_number);
                intent.putExtra("user_name",user_name);
                intent.putExtra("post_number",holder.postnum);
                startActivity(intent);
            });

            //設置巢狀RecyclerView
            if(holder.picnum > 0){
                System.out.println("照片數量 = "+holder.picnum);
                holder.nestedScrollView.setVisibility(View.VISIBLE);
                holder.recyclerView.setAdapter(new PicListAdapter(thisActivity, holder.postnum, holder.picnum));
                holder.recyclerView.setRecycledViewPool(viewPool);
            }else{
                holder.nestedScrollView.setVisibility(View.GONE);
            }
        }

        //決定顯示數量
        @Override
        public int getItemCount() {
            int size = 0;
            while (!finished){
                System.out.println("還沒結束");
            }
            size = postdata.size();
            return size;
        }
    }

    //貼文內的照片
    class PicListAdapter extends RecyclerView.Adapter<PersonalActivity.PicListAdapter.ViewHolder>{
        private int postnum; //這些照片所屬的貼文編號
        private int count; //所屬的貼文有幾個照片

        class ViewHolder extends RecyclerView.ViewHolder{
            private ImageView pic;
            private View mView;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                pic = itemView.findViewById(R.id.recycleview_post_pic);
                mView  = itemView;
            }
        }

        public PicListAdapter(PersonalActivity a, int post_num, int pic_count) {
            super();
            //thisActivity = a;
            postnum = post_num;
            count = pic_count;
        }

        @NonNull
        @Override
        public PicListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //原本返回type為RecyclerView.ViewHolder
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.recycle_item_pic_post,parent,false);
            return new PicListAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final PicListAdapter.ViewHolder holder, int position) {
            // 定义服务器上图像的URL
            String imageUrl = "http://140.127.220.89/image/user"+user_number+"_"+postnum+"_"+(holder.getAdapterPosition()+1)+".png";
            // 使用 Glide 加载图像
            Glide.with(PersonalActivity.this)
                    .load(imageUrl)
                    .into(holder.pic);

            holder.pic.setOnClickListener(v -> {
                //取得點擊到的item，並放大
                System.out.println("已點擊照片");
            });
        }

        //決定顯示數量
        @Override
        public int getItemCount() {
            return count;
        }
    }

    public String[] getData(){
        String[] data = new String[3];
        return data;
    }

    public String getHashtag(String tagId){
        String result = null;
        return result;
    }

    private class PostData{
        private int Number; //貼文編號
        private String Date;
        private String Context;
        private String classification;
        private int PictureNum;
   }

    public void getpost(int userNumber) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"diary\" WHERE user_number = "+userNumber;
                    ResultSet resultSet = statement.executeQuery(sql);

                    // 找尋一樣的帳號密碼
                    while (resultSet.next()) {
                        PostData p = new PostData();
                        p.Number = resultSet.getInt("diary_number");
                        p.Context = resultSet.getString("diary_content");
                        p.Date = resultSet.getString("diary_date");
                        p.classification = resultSet.getString("classification");
                        p.PictureNum = resultSet.getInt("image_count");
                        postdata.add(p);

                        //System.out.println("第"+ii+"筆資料 diary_number為"+p.Number+"    diary_content為"+p.Context+"   diary_date為"+p.Date);
                    }

                    finished = true;
                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    void sort(){
        if(postdata.size() > 1){
            int size = postdata.size();
            System.out.println("開始排序(size = "+size+")");

            for (int i = 0 ; i < size ; i++){
                for (int j = size - 1 ; j >  0 ; j--){
                    if(postdata.get(j).Number > postdata.get(j-1).Number){
                        PostData temp = postdata.get(j);
                        postdata.set( j , postdata.get(j-1) );
                        postdata.set( j - 1 , temp );
                    }
                }
            }
            sorted = true;

//            for(int i = 0 ; i < postdata.size() ; i++){
//                System.out.println("排序後的postdata的Num = "+postdata.get(i).Number);
//            }
        }else if(postdata.size() == 1){
            sorted = true;
        }
    }

    public void deleteDiary(int user_num, int post_num, int picNum) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "DELETE FROM \"diary\" WHERE user_number = "+user_num+" AND diary_number = "+post_num;
                    System.out.println(sql);
                    delected_diary = statement.executeUpdate(sql);

                    if(delected_diary == 1 && picNum > 0){
                        deleteDiaryImage(user_number, post_num);;
                    }

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException | InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void deleteDiaryImage(int user_num, int post_num) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "DELETE FROM \"diary_image\" WHERE user_number = "+user_num+" AND diary_number = "+post_num;
                    System.out.println(sql);
                    delected_diary_image = statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();


                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getNowMood() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String nowDate = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT * FROM \"facebook\" WHERE user_number = "+user_number+" AND fb_post_date = to_date('"+nowDate+"', 'YYYY-MM-DD')";
                    //System.out.println(sql);
                    ResultSet resultSet = statement.executeQuery(sql);
                    int fb_count = 0;
                    double sores = 0;
                    int i = 0;
                    while (resultSet.next()) {
                        if(i == 0) fb_score = 0;
                        fb_count++;
                        sores += Double.parseDouble(resultSet.getString("fb_post_scores"));
                        i++;
                    }
                    if(fb_count > 0){ //今天有發文
                        if(fb_count > fb_num) fb_num = fb_count;
                        fb_score = sores / fb_num;
                    }else{
                        fb_score = -1;
                    }



                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    sql = "SELECT * FROM \"txt\" WHERE user_number = "+user_number+ " AND txt_date = to_date('" +date_text+ "', 'YYYY-MM-DD') AND txt_score != -1";
                    System.out.println("sql為："+sql);
                    resultSet = statement.executeQuery(sql);
                    int txt_count = 0;
                    sores = 0;
                    i = 0;
                    while (resultSet.next()) {
                        if(i == 0) txt_score = 0;
                        txt_count++;
                        if(!resultSet.getString("txt_score").equals("null") && resultSet.getString("txt_score") != null){
                            System.out.println("txt_score = "+resultSet.getString("txt_score"));
                            sores += Double.valueOf(resultSet.getString("txt_score"));
                        }
                        i++;
                    }
                    System.out.println("txt_count = "+txt_count);
                    if(txt_count > 0){ //今天有上傳聊天紀錄
                        if(txt_count > txt_num) ins_num = txt_count;
                        txt_score = sores / ins_num;
                    }else {
                        txt_score = -1;
                    }


                    sql = "SELECT * FROM \"instagram\" WHERE user_number = "+user_number+ " AND ins_post_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    System.out.println("sql為："+sql);
                    resultSet = statement.executeQuery(sql);
                    int ig_count = 0;
                    sores = 0;
                    i = 0;
                    while (resultSet.next()) {
                        if(i == 0) ins_score = 0;
                        ig_count++;
                        sores += Double.valueOf(resultSet.getString("ins_post_scores"));
                        i++;
                    }
                    if(ig_count > 0){ //今天有發文
                        if(ig_count > ins_num) ins_num = ig_count;
                        ins_score = sores / ins_num;
                    }else {
                        ins_score = -1;
                    }


                    sql = "SELECT * FROM \"diary\" WHERE user_number = "+user_number+ " AND diary_date = to_date('" +date_text+ "', 'YYYY-MM-DD')";
                    System.out.println("sql為："+sql);
                    resultSet = statement.executeQuery(sql);
                    int post_count = 0;
                    sores = 0;
                    i = 0;
                    while (resultSet.next()) {
                        if(i == 0) post_score = 0;
                        post_count++;
                        sores += Double.valueOf(resultSet.getString("diary_score"));
                        i++;
                    }
                    if(post_count > 0){ //今天有寫日記
                        post_score = sores / post_count;
                    }else post_score = -1;


                    resultSet.close();
                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();


        double m = 0;
        int num = 0;
        int change_counnt = 0;
        if(txt_score > 0) {
            m += txt_score;
            change_counnt++;
            num++;
        }
        if(fb_score > 0) {
            m += fb_score;
            change_counnt++;
            num++;
        }
        if(ins_score > 0) {
            m += ins_score;
            change_counnt++;
            num++;
        }
        if(post_score > 0) {
            m += post_score;
            change_counnt++;
            num++;
        }
        if(m > 0 && num > 0) m = m / num;
        //System.out.println("現在心情："+m);

        mood.setImageDrawable(moodPics.getMoodPic(m));
        if(change_counnt == 0) mood.setImageDrawable(getResources().getDrawable(R.drawable.question));
    }

    static void changeUserName(String userName){
        name.setText(userName);
        user_name = userName;
        myListAdapter.notifyDataSetChanged();
    }
}