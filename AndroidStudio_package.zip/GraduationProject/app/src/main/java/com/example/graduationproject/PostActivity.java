package com.example.graduationproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class PostActivity extends AppCompatActivity {
    private int user_number;
    private String user_name;
    private int post_number;
    private String user_pic_name;

    private TextView date;
    private TextView name;
    private TextView content;
    private TextView classification;
    private ImageView pic;
    private ArrayList<String> iamge_name = new ArrayList<>();

    ImageView back;

    RecyclerView mRecyclerView;
    LinearLayoutManager linearLayoutManager;
    MyRvAdapter myRvAdapter;
    private boolean finished = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        ActivityCollector.addActivity(this);

        back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            ActivityCollector.removeActivity(this);
            finish();
        });

        Intent i = getIntent();
        user_number = i.getIntExtra("user_number", 0);
        user_name = i.getStringExtra("user_name");
        post_number = i.getIntExtra("post_number" , 0);

        date = findViewById(R.id.date);
        name = findViewById(R.id.name);
        name.setText(user_name);
        content = findViewById(R.id.content);
        classification = findViewById(R.id.classification);
        pic = findViewById(R.id.pic);

        while (!finished){
            System.out.println("正在載入");
            try {
                getPost();
                getPostImage();
                finished = true;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(iamge_name.size());

        //設置RecycleView
        mRecyclerView = findViewById(R.id.recycleview);
        linearLayoutManager = new LinearLayoutManager(PostActivity.this, LinearLayoutManager.HORIZONTAL, false);
        myRvAdapter = new MyRvAdapter();
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(myRvAdapter);
    }

    class MyRvAdapter extends RecyclerView.Adapter<MyRvAdapter.MyHolder>{
        class MyHolder extends RecyclerView.ViewHolder{
            ImageView pic;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                pic = itemView.findViewById(R.id.recycleview_post_pic);
            }
        }

        @NonNull
        @Override
        public MyRvAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_pic,parent,false);
            return new MyRvAdapter.MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final MyRvAdapter.MyHolder holder, int position) {
            String imageUrl = "http://140.127.220.89/image/user"+user_number+"_"+post_number+"_"+(holder.getAdapterPosition()+1)+".png";
            // 使用 Glide 加载图像
            Glide.with(PostActivity.this)
                    .load(imageUrl)
                    .into(holder.pic);
        }

        @Override
        public int getItemCount() {
            return iamge_name.size();
        }
    }

    public void getPost() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"diary\" WHERE user_number = "+user_number+" AND diary_number = "+post_number;
                    ResultSet resultSet = statement.executeQuery(sql);

                    // 找尋一樣的帳號密碼
                    while (resultSet.next()) {
                        date.setText(resultSet.getString("diary_date"));
                        content.setText(resultSet.getString("diary_content"));
                        classification.setText("分類："+resultSet.getString("classification"));
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getPostImage() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT image_name FROM \"diary_image\" WHERE user_number = "+user_number+" AND diary_number = "+post_number;
                    System.out.println(sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        iamge_name.add(resultSet.getString("image_name"));
                        System.out.println(resultSet.getString("image_name"));
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }


}