package com.example.graduationproject;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;

public class MoodPics {
    public Drawable[] mood_pics = new Drawable[5];
    @SuppressLint("UseCompatLoadingForDrawables")
    public MoodPics(Context context){
        mood_pics[0] = context.getResources().getDrawable(R.drawable.mood_1); //極度快樂
        mood_pics[1] = context.getResources().getDrawable(R.drawable.mood_2);
        mood_pics[2] = context.getResources().getDrawable(R.drawable.mood_3); //普通
        mood_pics[3] = context.getResources().getDrawable(R.drawable.mood_4);
        mood_pics[4] = context.getResources().getDrawable(R.drawable.mood_5); //極度不快樂
    }

    public Drawable getMoodPic(double score){
        Drawable pic = mood_pics[4]; //score < 0.2
        if (0.2 < score && score <= 0.4){
            pic = mood_pics[3];
        }else if (0.4 < score && score <= 0.6){
            pic = mood_pics[2];
        }else if (0.6 < score && score <= 0.8){
            pic = mood_pics[1];
        }else if (0.8 < score && score <= 1){
            pic = mood_pics[0];
        }
        return pic;
    }

//    public Drawable getMoodPic(double score){
//        Drawable pic = mood_pics[0]; //score < 0.2
//        if (0.2 < score && score <= 0.4){
//            pic = mood_pics[1];
//        }else if (0.4 < score && score <= 0.6){
//            pic = mood_pics[2];
//        }else if (0.6 < score && score <= 0.8){
//            pic = mood_pics[3];
//        }else if (0.8 < score && score <= 1){
//            pic = mood_pics[4];
//        }
//        return pic;
//    }

    public Drawable getMoodPic(int index){
        return mood_pics[index];
    }
}
