package com.example.graduationproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PersonalEditActivity extends AppCompatActivity {
    RecyclerView mRecyclerView;
    LinearLayoutManager linearLayoutManager;
    MyRvAdapter myRvAdapter;

    TextView cancel;
    TextView done;

    EditText line_edit;
    EditText fb_edit;
    EditText ins_edit;
    EditText name_edit;
    ImageView logout;

    private int user_number;
    private String user_name;
    private String line_id;
    private String fb_link;
    private String ins_link;
    private TextView classification_text;
    private LinearLayout recycleview_layout;
    private ImageView insert;

    boolean finish = false;

    ArrayList<String> diaryClassification = new ArrayList<>();
    private int delected = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_edit);
        ActivityCollector.addActivity(this);

        Intent i = getIntent();
        user_number = i.getIntExtra("number" , 0);
        try {
            getuser(user_number);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(view -> {
            ActivityCollector.removeActivity(this);
            finish();
        });

        name_edit = findViewById(R.id.name_edit);
        if (user_name != null) name_edit.setText(user_name);

        line_edit = findViewById(R.id.line_edit);
        if (line_id != null) line_edit.setText(line_id);

        fb_edit = findViewById(R.id.fb_edit);
        if (fb_link != null) fb_edit.setText(fb_link);

        ins_edit = findViewById(R.id.ins_edit);
        if (ins_link != null) ins_edit.setText(ins_link);

        try {
            getDiaryClassification(user_number);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        classification_text = findViewById(R.id.classification_text);
        recycleview_layout = findViewById(R.id.recycleview_layout);
        insert = findViewById(R.id.insert);
        insert.setOnClickListener(view -> {
            showDialog();
        });

        if(diaryClassification.size() == 0){
            recycleview_layout.setVisibility(View.GONE);
            classification_text.setText("貼文分類：尚未資料");
        }

        //設置RecycleView
        mRecyclerView = findViewById(R.id.recycleview);
        linearLayoutManager = new LinearLayoutManager(PersonalEditActivity.this, LinearLayoutManager.VERTICAL, false);
        myRvAdapter = new MyRvAdapter();
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(myRvAdapter);

        done = findViewById(R.id.done);
        done.setOnClickListener(view -> {
            if(!name_edit.getText().toString().isEmpty()){
                try {
                    save(user_number);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if(finish) Toast.makeText(getApplicationContext(), "更新成功", Toast.LENGTH_SHORT).show(); else Toast.makeText(getApplicationContext(), "更新失敗，請重試", Toast.LENGTH_SHORT).show();
                if(!name_edit.getText().toString().equals(user_name)){
                    System.out.println("更改名字");
                    MainActivity.changeUserName(name_edit.getText().toString());
                    PersonalActivity.changeUserName(name_edit.getText().toString());
                }
                String[] text = {line_edit.getText().toString(), fb_edit.getText().toString(), ins_edit.getText().toString()};
                MainActivity.changeLink(text);
                ActivityCollector.removeActivity(this);
                finish();
            }else Toast.makeText(getApplicationContext(), "名稱不可為空", Toast.LENGTH_SHORT).show();
        });

        logout = findViewById(R.id.logout);
        logout.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(this , LoginActivity.class); //現在,跳轉目標
            startActivity(intent);
            ActivityCollector.finishAll();
        });
    }

    class MyRvAdapter extends RecyclerView.Adapter<MyRvAdapter.MyHolder>{
        class MyHolder extends RecyclerView.ViewHolder{
            EditText classification_name;
            Button revise;
            Button delete;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                classification_name = itemView.findViewById(R.id.name);
                revise = itemView.findViewById(R.id.revise);
                delete = itemView.findViewById(R.id.delete);
            }
        }

        @NonNull
        @Override
        public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_diary_classification,parent,false);
            return new MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final MyHolder holder, int position) {
            holder.classification_name.setText(diaryClassification.get(holder.getAdapterPosition()));
            holder.revise.setOnClickListener(v -> {
                try {
                    updateDiaryClassification(diaryClassification.get(holder.getAdapterPosition()), holder.classification_name.getText().toString());
                    diaryClassification.set(holder.getAdapterPosition(), holder.classification_name.getText().toString());
                    UpdateDiaryClassificationCondition(diaryClassification.get(holder.getAdapterPosition()), holder.classification_name.getText().toString());
                    Toast.makeText(getApplicationContext(), "修改成功", Toast.LENGTH_SHORT).show();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "修改失敗", Toast.LENGTH_SHORT).show();
                }
            });
            holder.delete.setOnClickListener(v -> {
                try {
                    deleteDiaryClassification(holder.classification_name.getText().toString());
                    UpdateDiaryClassificationCondition(holder.classification_name.getText().toString());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(delected == 1){
                    diaryClassification.remove(holder.getAdapterPosition());
                    notifyItemRemoved(holder.getAdapterPosition());
                    Toast.makeText(getApplicationContext(), "刪除成功", Toast.LENGTH_SHORT).show();
                    delected = 0;
                }else{
                    Toast.makeText(getApplicationContext(), "刪除失敗", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            if(diaryClassification.size() == 0){
                recycleview_layout.setVisibility(View.GONE);
                classification_text.setText("貼文分類：尚未資料");

            }
            return diaryClassification.size();
        }
    }

    public void save(int user_number) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "UPDATE \"user\" SET user_name = '" + name_edit.getText().toString() + "', fb_link = '"+fb_edit.getText().toString()+"', ins_link = '"+ins_edit.getText().toString()+"', line_id = '"+line_edit.getText().toString()+"' WHERE user_number = " + user_number;
                    System.out.println(sql);
                    statement.executeUpdate(sql);

                    finish = true;
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getuser(int userNumber) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"user\" WHERE user_number = "+userNumber;
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        user_name = resultSet.getString("user_name");
                        line_id = resultSet.getString("line_id");
                        fb_link = resultSet.getString("fb_link");
                        ins_link = resultSet.getString("ins_link");
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getDiaryClassification(int userNumber) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"diary_classification\" WHERE user_number = "+userNumber;
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        diaryClassification.add(0, resultSet.getString("classification"));
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    private void showDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        EditText editText = new EditText(this); //final一個editText
        builder.setView(editText);
        builder.setTitle("請輸入分類名稱");

        builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                boolean exist = false;
                for (int j = 0 ; j < diaryClassification.size() ; j++){
                    if(diaryClassification.get(j).equals(editText.getText().toString())){
                        exist = true;
                    }
                }
                if(!exist){
                    try {
                        insertDiaryClassification(editText.getText().toString());
                        recycleview_layout.setVisibility(View.VISIBLE);
                        classification_text.setText("貼文分類：");
                        diaryClassification.add(0, editText.getText().toString());
                        myRvAdapter.notifyItemInserted(0);
                        Toast.makeText(PersonalEditActivity.this, "新增成功", Toast.LENGTH_SHORT).show();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Toast.makeText(PersonalEditActivity.this, "新增失敗", Toast.LENGTH_SHORT).show();
                    }

                }else Toast.makeText(PersonalEditActivity.this, "已有相同的分類", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }

    public void insertDiaryClassification(String classification_name) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "INSERT INTO \"diary_classification\" (\"user_number\" , \"classification\") VALUES (\'"+user_number+"\' , \'"+classification_name+"\')";
                    System.out.println(sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void deleteDiaryClassification(String classification_name) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String sql = "DELETE FROM \"diary_classification\" WHERE user_number = "+user_number+" AND classification = '"+classification_name+"'";
                    System.out.println(sql);
                    delected = statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void updateDiaryClassification(String classification_name_before , String classification_name_after) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "UPDATE \"diary_classification\" SET classification = '" + classification_name_after + "' WHERE user_number = " + user_number+" AND classification = '"+classification_name_before+"'";
                    System.out.println(sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void UpdateDiaryClassificationCondition(String classification_pre) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "UPDATE \"diary\" SET classification = \'整日日記\' WHERE user_number = "+user_number+" AND classification = \'"+classification_pre+"\'";

                    System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void UpdateDiaryClassificationCondition(String classification_pre, String classification_aft) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "UPDATE \"diary\" SET classification = \'"+classification_aft+"\' WHERE user_number = "+user_number+" AND classification = \'"+classification_pre+"\'";

                    System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }
}