package com.example.graduationproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RecordActivity extends AppCompatActivity {
    Context context;
    MoodPics moodPics;
    RecyclerView mRecyclerView;
    LinearLayoutManager linearLayoutManager;
    MyRvAdapter myRvAdapter;
    private int user_number;
    private int daily_diary;
    private String date_text;
    private String time;
    private int diary_number;
    String from;
    double mood_score = 0.9;

    public static final int CAMERA_PERM_CODE = 101;
    public static final int CAMERA_REQUEST_CODE = 102;
    ImageButton back;
    ImageButton save;
    TextView date;
    ImageView mood;
    EditText content;
    ImageButton camera;
    ImageButton picture;
    ImageButton location;
    LinearLayout location_layout;
    Spinner classification_spinner;
    Spinner mood_spinner;
    ImageView cancel;
    TextView location_text;
    LinearLayout pic_layout;

    private boolean record = false;
    String[] select_date;
    String select_week;

    ArrayList<Bitmap> select_pic = new ArrayList<>();
    ArrayList<String> diaryClassification = new ArrayList<>();//分類名稱


    double post_score = -1;
    double txt_score = -1;
    double fb_score = -1;
    double ins_score = -1;
    private int txt_num;
    private int fb_num;
    private int ins_num;

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        ActivityCollector.addActivity(this);

        context = this;
        moodPics = new MoodPics(this);

        Intent i = getIntent();
        //取得傳遞過來的資料
        String d = i.getStringExtra("date");
        select_date = d.split("-");
        select_week = i.getStringExtra("week");
        from = i.getStringExtra("from");
        user_number = i.getIntExtra("user_number",0);
        System.out.println("RecordActivity中的user_number = "+user_number);

        back = findViewById(R.id.back);
        back.setOnClickListener(view ->{
            ActivityCollector.removeActivity(this);
            finish();
        });

        String[] pic_text = {"極度快樂","開心","普通","不開心","極度不快樂"};
        mood_spinner = findViewById(R.id.mood_spinner);
        ArrayAdapter<String> mood_spinner_adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pic_text);
        mood_spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mood_spinner.setAdapter(mood_spinner_adapter);
        mood_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // test 1206
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mood.setImageDrawable(moodPics.getMoodPic(position));
                switch (position){
                    case 4:
                        mood_score = 0.1;
                        break;
                    case 3:
                        mood_score = 0.3;
                        break;
                    case 2:
                        mood_score = 0.5;
                        break;
                    case 1:
                        mood_score = 0.7;
                        break;
                    case 0:
                        mood_score = 0.9;
                        break;
                }
                //Toast.makeText(RecordActivity.this, "您選擇了第" + (position+1) + "個", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


        classification_spinner = findViewById(R.id.classification_spinner);
        try {
            getDiaryClassification();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ArrayAdapter<String> classification_spinner_adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, diaryClassification);
        classification_spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        classification_spinner.setAdapter(classification_spinner_adapter);


        save = findViewById(R.id.save);
        save.setOnClickListener(view ->{
            try {
                saveDiary();
                MainActivity.changeNowMood();
                System.out.println("已更改主頁心情");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if(!content.getText().toString().isEmpty()){
                if(record){
                    Toast.makeText(context, "新增成功", Toast.LENGTH_SHORT).show();
                    ActivityCollector.removeActivity(this);
                    if(from.equals("Mission")){
                        if(classification_spinner.getSelectedItem().toString().equals("整日日記")){
                            MissionActivity.changeMissionCondition(1);
                        }else MissionActivity.changeMissionCondition(0,daily_diary);
                    }
                    finish();
                }else{
                    Toast.makeText(this, "新增失敗", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(this,"日記不可空白",Toast.LENGTH_SHORT).show();
            }
        });

        date = findViewById(R.id.date);
        String text = select_date[0]+"年"+select_date[1]+"月"+select_date[2]+"日"+select_week;
        date.setText(text);

        mood = findViewById(R.id.mood);
        mood.setImageDrawable(moodPics.getMoodPic(4));

        content = findViewById(R.id.content);
        camera = findViewById(R.id.camera);
        camera.setOnClickListener(view ->{
            if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,new String[] {android.Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
            }else {
                openCamera();
            }
        });

        picture = findViewById(R.id.picture);
        picture.setOnClickListener(view ->{
            //打開相簿
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            //選擇相片後接回傳
            startActivityForResult(intent, 1);
        });

        location_text = findViewById(R.id.location_text);
        location = findViewById(R.id.location);
        location.setOnClickListener(view ->{
            location_layout.setVisibility(View.VISIBLE);
            location_text.setText("位置："+address());
        });

        location_layout = findViewById(R.id.location_layout);
        location_layout.setVisibility(View.GONE);

        cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(view ->{
            location_layout.setVisibility(View.GONE);
        });

        pic_layout = findViewById(R.id.pic_layout);

        //設置RecycleView
        mRecyclerView = findViewById(R.id.recycleview);
        linearLayoutManager = new LinearLayoutManager(RecordActivity.this, LinearLayoutManager.HORIZONTAL, false);
        myRvAdapter = new MyRvAdapter();
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(myRvAdapter);
    }

    class MyRvAdapter extends RecyclerView.Adapter<MyRvAdapter.MyHolder>{
        class MyHolder extends RecyclerView.ViewHolder{
            ImageView pic;
            ImageView delete;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                pic = itemView.findViewById(R.id.select_pic);
                delete = itemView.findViewById(R.id.delete);
            }
        }

        @NonNull
        @Override
        public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_item_pic,parent,false);
            return new MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final MyHolder holder, int position) {
            holder.pic.setImageBitmap(select_pic.get(holder.getAdapterPosition()));
            holder.delete.setOnClickListener(v -> {
                select_pic.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
                if(select_pic.size() == 0){
                    pic_layout.setVisibility(View.GONE);
                }
            });
        }

        @Override
        public int getItemCount() {
            if(select_pic.size() == 0){
                pic_layout.setVisibility(View.GONE);
            }
            return select_pic.size();
        }
    }

    public void saveDiary() throws InterruptedException {
        if(content.getText().toString().isEmpty()){
            record = false;
        }else {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    String host = "140.127.220.89"; // IP
                    int port = 5432; //
                    String databaseName = "postgres"; //
                    String user = "postgres"; //
                    String password = "CrownRu"; //

                    //
                    Connection connection = null;

                    try {
                        // URL
                        String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                        // PostgreSQL JDBC
                        Class.forName("org.postgresql.Driver");

                        // �s��
                        connection = DriverManager.getConnection(url, user, password);

                        // ����SQL
                        Statement statement = connection.createStatement();

                        Time t = new Time();
                        t.setToNow();
                        String hour = String.valueOf(t.hour);
                        String minute = String.valueOf(t.minute);
                        String second = String.valueOf(t.second);
                        if(t.hour < 10) hour = "0"+hour;
                        if(t.minute < 10) minute ="0"+minute;
                        if(t.second < 10) second = "0"+second;
                        time = hour+":"+minute+":"+second; // t.hour為0-23


                        getUser_number();
                        date_text = select_date[0]+"/"+select_date[1]+"/"+select_date[2];
                        String sql = "INSERT INTO \"diary\" (\"diary_content\", \"user_number\", \"diary_date\", \"diary_time\", \"classification\", \"image_count\", \"diary_score\") VALUES ('"+content.getText().toString()+"', "+user_number+", to_date('" +date_text+ "', 'YYYY-MM-DD'), '"+time+"', '"+classification_spinner.getSelectedItem().toString()+"', "+select_pic.size()+", "+mood_score+")";
                        System.out.println("sql為："+sql);
                        statement.executeUpdate(sql);

                        statement.close();


                        uploadPhoto();

                        record = true;

                        connection.close();

                        int type = 2;
                        if(classification_spinner.getSelectedItem().toString().equals("整日日記")) type = 1;
                            UpdateMissionCondition(type);
                    } catch (SQLException e) {
                        e.printStackTrace();
                        System.out.println("SQLException");
                    } catch (ClassNotFoundException | InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (connection != null) {
                                connection.close();
                            }else{
                                System.out.println("connection = null");
                                Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

            t.start();
            t.join();
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == CAMERA_PERM_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                openCamera();
            }else {
                Toast.makeText(this, "Camera Permission is Required to Use camera.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openCamera() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camera, CAMERA_REQUEST_CODE);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST_CODE){ //照相
            Bitmap image = (Bitmap) data.getExtras().get("data");
            select_pic.add(0, image);
            myRvAdapter.notifyItemInserted(0);
            pic_layout.setVisibility(View.VISIBLE);

        }else if (resultCode == RESULT_OK) { //照片
            Uri uri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                select_pic.add(0, bitmap);
                myRvAdapter.notifyItemInserted(0);
                pic_layout.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "圖片選取失敗", Toast.LENGTH_SHORT).show();
            }
        }
    }

    void getUser_number(){
        Intent i = getIntent();
        user_number = i.getIntExtra("user_number",0);
    }

    public void uploadPhoto() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89";
                String userName = "a1093364"; //
                String password = "CrownRu";
                String remoteFilePath = "/var/www/html/image/";

                try {
                    JSch jsch = new JSch();
                    Session session = jsch.getSession(userName, host, 22);
                    session.setPassword(password);

                    // 不要检查主机密钥
                    java.util.Properties config = new java.util.Properties();
                    config.put("StrictHostKeyChecking", "no");
                    session.setConfig(config);

                    // 连接到服务器
                    session.connect();

                    // 使用ChannelSftp上传文件
                    Channel channel = session.openChannel("sftp");
                    channel.connect();

                    ChannelSftp sftpChannel = (ChannelSftp) channel;

                    for (int i = 0 ; i < select_pic.size() ; i++) {
                        // 上传文件
                        sftpChannel.put(saveBitmapToPath(select_pic.get(i), i + 1), remoteFilePath);
                        insertPic(i+1);
                    }

                    // 关闭连接
                    sftpChannel.exit();
                    session.disconnect();
                } catch (JSchException | SftpException | InterruptedException e) {
                    e.printStackTrace();
                    try {
                        deleteDiary();
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public String saveBitmapToPath(Bitmap bitmap, int index) {
        try {
            getDiaryNumber();

            String fileName = "user"+user_number+"_"+diary_number+"_"+index+".png";
            // 创建一个文件对象，指定保存路径和文件名
            File file = bitmapToMemoryFile(bitmap, fileName);

            // 创建文件输出流
            FileOutputStream fileOutputStream = new FileOutputStream(file);

            // 将Bitmap保存为PNG格式，第二个参数是图片质量，可以根据需要调整
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);

            // 关闭文件输出流
            fileOutputStream.close();

            // 返回保存文件的路径
            return file.getAbsolutePath();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public File bitmapToMemoryFile(Bitmap bitmap, String fileName) {
        try {
            File file = new File(getCacheDir(), fileName);

            // 创建一个文件输出流
            FileOutputStream fileOutputStream = new FileOutputStream(file);

            // 将 Bitmap 压缩为 PNG 格式，可以根据需要调整格式和质量
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);

            // 关闭文件输出流
            fileOutputStream.close();

            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void deleteDiary() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String sql = "DELETE FROM \"diary\" WHERE user_number = "+user_number+" AND diary_date = to_date(\'" +date_text+"\', \'YYYY-MM-DD\') AND diary_time = '"+time+"'";
                    System.out.println(sql);
                    statement.executeUpdate(sql);

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void insertPic(int index) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String pic_name = "user"+user_number+"_"+diary_number+"_"+index+".png";
                    String sql = "INSERT INTO \"diary_image\" (\"diary_number\", \"user_number\", \"image_name\") VALUES ("+diary_number+", "+user_number+", \'" +pic_name+"\')";
                    statement.executeUpdate(sql);

                    //System.out.println("sql為："+sql);
                    statement.close();
                    connection.close();

                    record = true;
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getDiaryNumber() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"diary\" WHERE user_number = "+user_number+" AND diary_date = to_date(\'" +date_text+"\', \'YYYY-MM-DD\') AND diary_time = '"+time+"'";
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        diary_number = resultSet.getInt("diary_number");
                    }

                    resultSet.close();
                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getDiaryClassification() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"diary_classification\" WHERE user_number = "+user_number;
                    ResultSet resultSet = statement.executeQuery(sql);

                    diaryClassification.add("整日日記");
                    while (resultSet.next()) {
                        diaryClassification.add(resultSet.getString("classification"));
                    }

                    resultSet.close();
                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void UpdateMissionCondition(int type) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String text = "dm_report";
                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql;
                    if(type == 1){ //整日日記
                        sql = "UPDATE \"daily_mission\" SET dm_diary = true WHERE user_number = "+user_number+" AND dm_date = to_date(\'" +date_text+ "\', \'YYYY-MM-DD\')";
                    }else{ //自定義分類
                        getMissionCondition();
                        daily_diary++;
                        sql = "UPDATE \"daily_mission\" SET dm_daily_diary = "+daily_diary+" WHERE user_number = "+user_number+" AND dm_date = to_date(\'" +date_text+ "\', \'YYYY-MM-DD\')";
                    }

                    System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException | InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getMissionCondition() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String date_text = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
                    String sql = "SELECT * FROM \"daily_mission\" WHERE user_number = "+user_number+" AND dm_date = to_date(\'" +date_text+ "\', \'YYYY-MM-DD\')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    while (resultSet.next()) {
                        daily_diary = resultSet.getInt("dm_daily_diary");
                    }

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public String address() {
        String addressName = "";
        String commadStr = LocationManager.GPS_PROVIDER;

        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            int FINE_PERMISSION_CODE = 1;
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, FINE_PERMISSION_CODE);
            return "";
        }
        Location location = locationManager.getLastKnownLocation(commadStr);

        if (location != null) {
            Float latitude = (float) location.getLatitude();
            Float longitude = (float) location.getLongitude();

            Geocoder geoCoder = new Geocoder(this, Locale.getDefault());
            try {
                List<Address> addressList = geoCoder.getFromLocation(latitude, longitude, 3);
                if (addressList.size() != 0) {
                    if (addressList.get(0).getCountryName() != null) {
                        addressName += addressList.get(0).getCountryName();
                    }
                    if (addressList.get(0).getAdminArea() != null) {
                        addressName += ", " + addressList.get(0).getAdminArea();
                    }
                    if (addressList.get(0).getSubAdminArea() != null) {
                        addressName += ", " + addressList.get(0).getSubAdminArea();
                    }
                }
                if (addressName == "") {
                    addressName = "未知地址";
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return addressName;
    }
}