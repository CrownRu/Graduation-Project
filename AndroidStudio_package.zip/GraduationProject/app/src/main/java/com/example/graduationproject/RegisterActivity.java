package com.example.graduationproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegisterActivity extends AppCompatActivity {

    ImageButton back;
    ImageView register;
    EditText account;
    EditText password;
    EditText name;
    EditText fb;
    EditText ig;
    private boolean canAdd = true;
    private boolean finishAdd = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        back = findViewById(R.id.back);
        back.setOnClickListener(view -> this.finish());

        account = findViewById(R.id.account);
        password = findViewById(R.id.password);
        name = findViewById(R.id.name);
        fb = findViewById(R.id.fb);
        ig = findViewById(R.id.ig);

        register = findViewById(R.id.register);
        register.setOnClickListener(view -> {
            if(!account.getText().toString().isEmpty() && !password.getText().toString().isEmpty()){
                try {
                    checkaccount(account.getText().toString(), password.getText().toString(), name.getText().toString());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (canAdd){
                    if(finishAdd){
                        finish();
                        Toast.makeText(getApplicationContext(), "帳號創建成功", Toast.LENGTH_SHORT).show();
                    }else Toast.makeText(getApplicationContext(), "帳號創建失敗", Toast.LENGTH_SHORT).show();

                } else Toast.makeText(getApplicationContext(), "已有相同的帳號名稱，請更換帳號", Toast.LENGTH_SHORT).show();

            }else{
                Toast.makeText(this,"帳號或密碼不可空白",Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void checkaccount(String account_input, String password_input, String name_input) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"user\" WHERE account = '" + account_input + "'";
                    ResultSet resultSet = statement.executeQuery(sql);

                    int count = 0;
                    while (resultSet.next()) {
                        count++;
                    }

                    if (count > 0) {
                        canAdd = false;
                    }

                    if(canAdd){
                        addaccount(account_input, password_input, name_input);
                        finishAdd = true;
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException | InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void addaccount(String account_input, String password_input, String name_input) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "INSERT INTO \"user\" (\"account\", \"password\", \"user_name\", \"fb_link\", \"ins_link\") VALUES ('" +account_input+"', '"+password_input+"', '"+name_input+"', '"+fb.getText().toString()+"', '"+ig.getText().toString()+"')";
                    System.out.println(sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }
}