package com.example.graduationproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginActivity extends AppCompatActivity {
    Context context;
    private boolean correct = false;
    ImageView register;
    ImageView login;
    EditText account;
    EditText password;
    private int user_number;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        context = this;

        account = findViewById(R.id.account);
        password = findViewById(R.id.password);

        register = findViewById(R.id.register);
        register.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setClass(this , RegisterActivity.class); //現在,跳轉目標
            startActivity(intent);
        });

        login = findViewById(R.id.login);
        login.setOnClickListener(view -> {
            try {
                getaccount(account.getText().toString(), password.getText().toString());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if(correct){
                Intent intent = new Intent();
                intent.setClass(this , MainActivity.class); //現在,跳轉目標
                intent.putExtra("account",account.getText().toString());
                intent.putExtra("from","Login");
                intent.putExtra("user_number",user_number);
                startActivity(intent);
                finish();
            }else{
                Toast.makeText(context, "帳號或密碼錯誤", Toast.LENGTH_SHORT).show();
            }

//            Intent intent = new Intent();
//            intent.setClass(this , MainActivity.class); //現在,跳轉目標
//            intent.putExtra("from","Login");
//            intent.putExtra("user_number",1);
//            startActivity(intent);
//            finish();
        });
    }

     public void getaccount(String account_input, String password_input) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    // URL
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"user\" WHERE account = '"+account_input+"' AND password = '"+password_input+"'";
                    ResultSet resultSet = statement.executeQuery(sql);

                    // 找尋一樣的帳號密碼
                    if (resultSet.next()) {
                        user_number = Integer.parseInt(resultSet.getString("user_number"));
                        correct = true;
                    }

                    resultSet.close();
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();


                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(context, "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }
}