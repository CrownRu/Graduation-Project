package com.example.graduationproject;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class ReportActivity extends AppCompatActivity {
    Context context;
    MoodPics moodPics;
    private int user_number;
    private int select_type = 1;
    private String select_day;

    ImageView back;
    ImageView setting;

    ImageView day;
    ImageView week;
    ImageView month;
    ImageView year;
    ImageView chart;

    ImageView date;
    TextView date_edit;
    TextView mood_avg_text;
    TextView post_num_text;
    TextView diary_num_text;
    ImageView mood;
    TextView chat;

    int date_year;
    int date_month;
    int date_day;

    double mood_avg = -1;
    int diary_num = 0;
    int txt_num = 0;
    int fb_num = 0;
    int ins_num = 0;
    double txt_mood = -1;
    double fb_mood = -1;
    double ins_mood = -1;
    double diary_mood = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        ActivityCollector.addActivity(this);

        moodPics = new MoodPics(this);
        context = this;

        Intent i = getIntent();
        user_number = i.getIntExtra("number",0);
        String from = i.getStringExtra("from");

        date = findViewById(R.id.date);
        date_edit = findViewById(R.id.date_edit);
        mood_avg_text = findViewById(R.id.mood_avg);
        post_num_text = findViewById(R.id.post);
        diary_num_text = findViewById(R.id.diary);
        mood = findViewById(R.id.mood);
        chat = findViewById(R.id.chat);
        calendar();

        back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            ActivityCollector.removeActivity(this);
            finish();
        });
        setting = findViewById(R.id.setting);

        day = findViewById(R.id.day);
        day.setOnClickListener(view -> {
            select_type = 1;
            changeClick(select_type);
            setchart(user_number,select_type,select_day);
        });

        week = findViewById(R.id.week);
        week.setOnClickListener(view -> {
            select_type = 2;
            changeClick(select_type);
            setchart(user_number,select_type,select_day);
        });

        month = findViewById(R.id.month);
        month.setOnClickListener(view -> {
            select_type = 3;
            changeClick(select_type);
            setchart(user_number,select_type,select_day);
        });

        year = findViewById(R.id.year);
        year.setOnClickListener(view -> {
            select_type = 4;
            changeClick(select_type);
            setchart(user_number,select_type,select_day);
        });

        chart = findViewById(R.id.chart);
        setchart(user_number,0,select_day);

        try {
            UpdateMissionCondition();
            if(from.equals("Mission")){
                MissionActivity.changeMissionCondition(3);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(this, "報表任務完成失敗，請稍後再試", Toast.LENGTH_SHORT).show();
        }

        getMoodAvg("日", select_day);
    }

    private void calendar() {
        Calendar calendar = Calendar.getInstance();
        String today = calendar.get(Calendar.YEAR) +"/"+ (calendar.get(Calendar.MONTH) + 1) +"/"+ calendar.get(Calendar.DAY_OF_MONTH);
        if(calendar.get(Calendar.DAY_OF_MONTH) < 10){
            select_day = calendar.get(Calendar.YEAR) +"-"+ (calendar.get(Calendar.MONTH) + 1) +"-0"+ calendar.get(Calendar.DAY_OF_MONTH);
        }else{
            select_day = calendar.get(Calendar.YEAR) +"-"+ (calendar.get(Calendar.MONTH) + 1) +"-"+ calendar.get(Calendar.DAY_OF_MONTH);
        }
        date_edit.setText(today);

        //取得Calender物件資訊
        date_year = calendar.get(Calendar.YEAR);
        date_month = calendar.get(Calendar.MONTH);
        date_day = calendar.get(Calendar.DAY_OF_MONTH);

        date.setOnClickListener(new View.OnClickListener() {
            //在點了按鈕後才跳出日曆
            @Override
            public void onClick(View view) {
                //取出年月日
                new DatePickerDialog(ReportActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        String dateTime = year +"/"+ (month + 1) +"/"+ day;
                        if(day < 10){
                            select_day = year +"-"+ (month + 1) +"-0"+ day;
                        }else{
                            select_day = year +"-"+ (month + 1) +"-"+ day;
                        }

                        date_edit.setText(dateTime);

                        //把日期改成現在選擇的日期
                        date_year = year;
                        date_month = month;
                        date_day = day;

                        switch (select_type){
                            case 0: //日
                                getMoodAvg("日",select_day);
                                break;
                            case 1: //週
                                getMoodAvg("週",select_day);
                                break;
                            case 2: //月
                                getMoodAvg("月",select_day);
                                break;
                            case 3: //年
                                getMoodAvg("年",select_day);
                                break;
                        }
                    }
                },date_year,date_month,date_day).show();

                setchart(user_number,select_type,select_day);
            }
        });
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void changeClick(int num) {

        Drawable[] day_button = {getResources().getDrawable(R.drawable.day), getResources().getDrawable(R.drawable.day_click)};
        Drawable[] week_button = {getResources().getDrawable(R.drawable.week), getResources().getDrawable(R.drawable.week_click)};
        Drawable[] month_button = {getResources().getDrawable(R.drawable.month), getResources().getDrawable(R.drawable.month_click)};
        Drawable[] year_button = {getResources().getDrawable(R.drawable.year), getResources().getDrawable(R.drawable.year_click)};
        Drawable[] mood_pic = {getResources().getDrawable(R.drawable.smile)};

        if(num == 1){ //按日
            mood_avg_text.setText("本日心情平均：");
            day.setImageDrawable(day_button[1]);
            week.setImageDrawable(week_button[0]);
            month.setImageDrawable(month_button[0]);
            year.setImageDrawable(year_button[0]);
            getMoodAvg("日",select_day);

        }else if(num == 2){ //按週
            mood_avg_text.setText("本週心情平均：");
            day.setImageDrawable(day_button[0]);
            week.setImageDrawable(week_button[1]);
            month.setImageDrawable(month_button[0]);
            year.setImageDrawable(year_button[0]);
            getMoodAvg("週",select_day);

        }else if(num == 3){ //按月
            mood_avg_text.setText("本月心情平均：");
            day.setImageDrawable(day_button[0]);
            week.setImageDrawable(week_button[0]);
            month.setImageDrawable(month_button[1]);
            year.setImageDrawable(year_button[0]);
            getMoodAvg("月",select_day);

        }else{ //按年
            mood_avg_text.setText("今年心情平均：");
            day.setImageDrawable(day_button[0]);
            week.setImageDrawable(week_button[0]);
            month.setImageDrawable(month_button[0]);
            year.setImageDrawable(year_button[1]);
            getMoodAvg("年",select_day);
        }
    }

    public void setchart(int userNum, int type, String date){
        String time = "day";
        switch (type){
            case 2 : time = "week"; break;
            case 3 : time = "month"; break;
            case 4 : time = "year"; break;
        }
        // 定义服务器上图像的URL
        String imageUrl = "http://140.127.220.89/image/user"+userNum+"_"+date+"_"+time+".png";
        Glide.get(this).clearMemory();
        new Thread(() -> Glide.get(context).clearDiskCache()).start();
        // 使用 Glide 加载图像
        Glide.with(this)
                .load(imageUrl)
                .into(chart);
    }

    public void UpdateMissionCondition() throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();


                    String date_text = new SimpleDateFormat("YYYY-MM-DD").format(new Date());
                    String sql = "UPDATE \"daily_mission\" SET dm_report = true WHERE user_number = "+user_number+" AND dm_date = to_date(\'" +date_text+ "\', \'YYYY-MM-DD\')";
                    System.out.println("sql為："+sql);
                    statement.executeUpdate(sql);

                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getMoodAvg(String type, String select_date){
        String start_date = "";
        //System.out.println("select_date = "+select_date);
        String[] date = select_date.split("-");
        LocalDate currentDate = LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]));
        switch (type){
            case "日":
                start_date = select_date;
                break;
            case "週":
                LocalDate sevenDaysAgo = currentDate.minusDays(6);
                start_date = sevenDaysAgo.getYear()+"-"+sevenDaysAgo.getMonth()+"-"+sevenDaysAgo.getDayOfMonth();
                break;
            case "月":
                LocalDate monthAgo = currentDate.minusDays(30);
                start_date = monthAgo.getYear()+"-"+monthAgo.getMonth()+"-"+monthAgo.getDayOfMonth();
                break;
            case "年":
                start_date = Integer.parseInt(date[0])-1+"-"+date[1]+"-"+date[2];
                break;
        }
        try {
            getDiaryMoodAvg(type, start_date, select_date);
            getLineMoodAvg(type, start_date, select_date);
            getFBMoodAvg(type, start_date, select_date);
            getIGMoodAvg(type, start_date, select_date);
        } catch (InterruptedException e) {
            e.printStackTrace();
            Toast.makeText(this, "資料加載失敗", Toast.LENGTH_SHORT).show();
        }

        double score = 0;
        int num = 0;
        if(txt_mood > 0) {
            score += txt_mood;
            num++;
        }
        if(fb_mood > 0) {
            score += fb_mood;
            num++;
        }
        if(ins_mood > 0) {
            score += ins_mood;
            num++;
        }
        if(diary_mood > 0) {
            score += diary_mood;
            num++;
        }
        if(score > 0 && num > 0) score = score / num;
        if(score == 0) score = 0.5;

        mood.setImageDrawable(moodPics.getMoodPic(score));
        post_num_text.setText("貼文總數："+(ins_num+fb_num));
        diary_num_text.setText("日記總數："+diary_num);
        chat.setText("聊天紀錄分析數量："+txt_num);
        Toast.makeText(this, "已更新", Toast.LENGTH_SHORT).show();
    }

    public void getLineMoodAvg(String type, String start_date, String end_date) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"txt\" WHERE user_number = "+user_number+" AND (txt_date BETWEEN '"+start_date+"' AND '"+end_date+"')";
                    System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    txt_num = 0;
                    txt_mood = -1;
                    double score = 0;
                    while (resultSet.next()) {
                        score += Double.valueOf(resultSet.getString("txt_score"));
                        txt_num++;
                    }

                    if (score > 0) txt_mood = score;

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getFBMoodAvg(String type, String start_date, String end_date) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"facebook\" WHERE user_number = "+user_number+" AND (fb_post_date BETWEEN '"+start_date+"' AND '"+end_date+"')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    fb_num = 0;
                    fb_mood = -1;
                    double score = 0;
                    while (resultSet.next()) {
                        score += Double.valueOf(resultSet.getString("fb_post_scores"));
                        fb_num++;
                    }

                    if (score > 0) fb_mood = score;

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getIGMoodAvg(String type, String start_date, String end_date) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"instagram\" WHERE user_number = "+user_number+" AND (ins_post_date BETWEEN '"+start_date+"' AND '"+end_date+"')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    ins_num = 0;
                    ins_mood = -1;
                    double score = 0;
                    while (resultSet.next()) {
                        score += Double.valueOf(resultSet.getString("ins_post_scores"));
                        ins_num++;
                    }

                    if (score > 0) ins_mood = score;

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }

    public void getDiaryMoodAvg(String type, String start_date, String end_date) throws InterruptedException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String host = "140.127.220.89"; // IP
                int port = 5432; //
                String databaseName = "postgres"; //
                String user = "postgres"; //
                String password = "CrownRu"; //

                //
                Connection connection = null;

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    String url = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName;

                    // PostgreSQL JDBC
                    Class.forName("org.postgresql.Driver");

                    // �s��
                    connection = DriverManager.getConnection(url, user, password);

                    // ����SQL
                    Statement statement = connection.createStatement();

                    String sql = "SELECT * FROM \"diary\" WHERE user_number = "+user_number+" AND (diary_date BETWEEN '"+start_date+"' AND '"+end_date+"')";
                    //System.out.println("sql為："+sql);
                    ResultSet resultSet = statement.executeQuery(sql);

                    diary_num = 0;
                    diary_mood = -1;
                    double score = 0;
                    while (resultSet.next()) {
                        score += Double.valueOf(resultSet.getString("diary_score"));
                        diary_num++;
                    }

                    if (score > 0) diary_mood = score;

                    statement.close();
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    System.out.println("SQLException");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (connection != null) {
                            connection.close();
                        }else{
                            System.out.println("connection = null");
                            Toast.makeText(getApplicationContext(), "無法連線至資料庫", Toast.LENGTH_SHORT).show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t.start();
        t.join();
    }
}